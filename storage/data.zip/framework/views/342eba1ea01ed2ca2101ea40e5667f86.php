<?php use App\Utils\ProductManager; ?>


<?php $__env->startSection('title', translate('all_Stores').' | '.$web_config['name']->value.' '.translate('ecommerce')); ?>

<?php $__env->startSection('content'); ?>
    <main class="main-content d-flex flex-column gap-3 py-3 mb-30">
        <div class="container">
            <div class="card mb-3">
                <div class="card-body">
                    <div class="row gy-2 align-items-center">
                        <div class="col-md-8">
                            <h3 class="mb-1 text-capitalize"><?php echo e(translate('all_stores')); ?></h3>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb fs-12 mb-0">
                                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><?php echo e(translate('home')); ?></a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        <a href="<?php echo e(route('vendors')); ?>"><?php echo e(translate('stores')); ?></a></li>
                                </ol>
                            </nav>
                        </div>
                        <div class="col-md-4">
                            <div class="custom_search position-relative float-end">
                                <form action="<?php echo e(route('search-shop')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="d-flex">
                                        <div
                                            class="select-wrap focus-border border border-end-logical-0 d-flex align-items-center">
                                            <input type="search"
                                                   class="form-control border-0 focus-input search-bar-input"
                                                   name="shop_name" placeholder="<?php echo e(translate('shop_name')); ?>" required>
                                        </div>
                                        <button type="submit" class="btn btn-primary">
                                            <i class="bi bi-search"></i>
                                        </button>
                                    </div>
                                </form>
                                <div
                                    class="card search-card __inline-13 position-absolute z-999 bg-white top-100 start-0 search-result-box"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="auto-col xxl-items-6 justify-content-center gap-3">
                        <?php $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php ($currentDate = date('Y-m-d')); ?>
                            <?php ($startDate = date('Y-m-d', strtotime($shop['vacation_start_date']))); ?>
                            <?php ($endDate = date('Y-m-d', strtotime($shop['vacation_end_date']))); ?>

                            <a href="<?php echo e(route('shopView',['id'=>$shop['seller_id']])); ?>"
                               class="store-item grid-center py-2">
                                <div class="position-relative">
                                    <div class="avatar rounded-circle border" style="--size: 6.875rem">
                                        <img class="dark-support img-fit rounded-circle img-w-h-100"
                                             src="<?php echo e(getValidImage(path: 'storage/app/public/shop/'.$shop->image, type:'shop')); ?>"
                                             alt="<?php echo e($shop->name); ?>" loading="lazy">
                                    </div>
                                    <?php if($shop->vacation_status && ($currentDate >= $startDate) && ($currentDate <= $endDate)): ?>
                                        <span class="temporary-closed position-absolute rounded-circle">
                                        <span><?php echo e(translate('closed_now')); ?></span>
                                    </span>
                                    <?php elseif($shop->temporary_close): ?>
                                        <span class="temporary-closed position-absolute rounded-circle">
                                        <span><?php echo e(translate('closed_now')); ?></span>
                                    </span>
                                    <?php endif; ?>
                                </div>

                                <div class="d-flex flex-column align-items-center flex-wrap gap-2 mt-3">
                                    <h6 class="text-truncate mx-auto text-center"><?php echo e(Str::limit($shop->name, 14)); ?></h6>
                                    <?php ($seller = ProductManager::get_user_total_product('seller', $shop->seller_id)); ?>
                                    <p><?php echo e($seller); ?> <?php echo e(translate('products')); ?></p>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <?php if(count($sellers) == 0): ?>
                        <div class="w-100 text-center pt-5">
                            <img width="120" class="mb-3" src="<?php echo e(theme_asset('assets/img/not_found.png')); ?>" alt="">
                            <h5 class="text-center text-muted"><?php echo e(translate('no_data_found')); ?>.</h5>
                        </div>
                    <?php endif; ?>
                    <div class="mt-5">
                        <?php echo e($sellers->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme-views.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/blunxtld/public_html/resources/themes/theme_aster/theme-views/seller-views/sellers.blade.php ENDPATH**/ ?>