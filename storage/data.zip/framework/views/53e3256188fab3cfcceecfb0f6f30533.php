<?php
    use App\Utils\CartManager;
    use App\Utils\Helpers;
?>
<div class="col-lg-4">
    <div class="card text-dark sticky-top-80">
        <div class="card-body px-sm-4 d-flex flex-column gap-2">
            <?php ($current_url=request()->segment(count(request()->segments()))); ?>
            <?php ($shippingMethod=getWebConfig(name: 'shipping_method')); ?>
            <?php ($product_price_total=0); ?>
            <?php ($total_tax=0); ?>
            <?php ($total_shipping_cost=0); ?>
            <?php ($order_wise_shipping_discount=CartManager::order_wise_shipping_discount()); ?>
            <?php ($total_discount_on_product=0); ?>
            <?php ($cart=CartManager::get_cart()); ?>
            <?php ($cart_group_ids=CartManager::get_cart_group_ids()); ?>
            <?php ($shipping_cost=CartManager::get_shipping_cost()); ?>
            <?php ($get_shipping_cost_saved_for_free_delivery=CartManager::get_shipping_cost_saved_for_free_delivery()); ?>
            <?php if($cart->count() > 0): ?>
                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php ($product_price_total+=$cartItem['price']*$cartItem['quantity']); ?>
                    <?php ($total_tax+=$cartItem['tax_model']=='exclude' ? ($cartItem['tax']*$cartItem['quantity']):0); ?>
                    <?php ($total_discount_on_product+=$cartItem['discount']*$cartItem['quantity']); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if(session()->missing('coupon_type') || session('coupon_type') !='free_delivery'): ?>
                    <?php ($total_shipping_cost=$shipping_cost - $get_shipping_cost_saved_for_free_delivery); ?>
                <?php else: ?>
                    <?php ($total_shipping_cost=$shipping_cost); ?>
                <?php endif; ?>
            <?php else: ?>
                <span><?php echo e(translate('empty_cart')); ?></span>
            <?php endif; ?>

            <div class="d-flex mb-3">
                <h5 class="text-capitalize"><?php echo e(translate('order_summary')); ?></h5>
            </div>
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
                <div><?php echo e(translate('item_price')); ?></div>
                <div><?php echo e(Helpers::currency_converter($product_price_total)); ?></div>
            </div>
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
                <div class="text-capitalize"><?php echo e(translate('product_discount')); ?></div>
                <div><?php echo e(Helpers::currency_converter($total_discount_on_product)); ?></div>
            </div>
            <?php ($coupon_discount = 0); ?>
            <?php ($coupon_dis=0); ?>
            <?php if(auth('customer')->check() && !session()->has('coupon_discount')): ?>
                <form class="needs-validation" action="<?php echo e(route('coupon.apply')); ?>" method="post" id="submit-coupon-code">
                    <?php echo csrf_field(); ?>
                    <div class="form-group my-3">
                        <label for="promo-code" class="fw-semibold"><?php echo e(translate('Promo_Code')); ?></label>
                        <div class="form-control focus-border pe-1 rounded d-flex align-items-center">
                            <input type="text" name="code" id="promo-code"
                                   class="w-100 text-dark bg-transparent border-0 focus-input"
                                   placeholder="<?php echo e(translate('write_coupon_code_here')); ?>" required>
                            <button class="btn btn-primary text-nowrap" id="coupon-code-apply"><?php echo e(translate('apply')); ?></button>
                        </div>
                    </div>
                </form>
            <?php endif; ?>

            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
                <div><?php echo e(translate('sub_total')); ?></div>
                <div><?php echo e(Helpers::currency_converter($product_price_total - $total_discount_on_product)); ?></div>
            </div>
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
                <div><?php echo e(translate('tax')); ?></div>
                <div><?php echo e(Helpers::currency_converter($total_tax)); ?></div>
            </div>
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
                <div><?php echo e(translate('shipping')); ?></div>
                <div class="text-primary"><?php echo e(Helpers::currency_converter($total_shipping_cost)); ?></div>
            </div>

            <?php ($coupon_discount = session()->has('coupon_discount')?session('coupon_discount'):0); ?>
            <?php ($coupon_dis=session()->has('coupon_discount')?session('coupon_discount'):0); ?>
            <?php if(auth('customer')->check() && session()->has('coupon_discount')): ?>
                <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
                    <div><?php echo e(translate('coupon_discount')); ?></div>
                    <div class="text-primary">
                         <?php echo e('-'.Helpers::currency_converter($coupon_discount+$order_wise_shipping_discount)); ?></div>
                </div>
            <?php endif; ?>
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
                <h4><?php echo e(translate('total')); ?></h4>
                <h2 class="text-primary"><?php echo e(Helpers::currency_converter($product_price_total+$total_tax+$total_shipping_cost-$coupon_dis-$total_discount_on_product-$order_wise_shipping_discount)); ?></h2>
            </div>
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mt-4">
                <a href="<?php echo e(route('home')); ?>" class="btn-link text-primary text-capitalize"><i
                        class="bi bi-chevron-double-left fs-10"></i> <?php echo e(translate('continue_shopping')); ?></a>
                <button
                    class="btn btn-primary text-capitalize <?php echo e(str_contains(request()->url(), 'checkout-payment') ? 'd-none':''); ?>"
                    id="proceed-to-next-action" data-goto-checkout="<?php echo e(route('customer.choose-shipping-address-other')); ?>"
                    data-checkout-payment="<?php echo e(route('checkout-payment')); ?>"
                    <?php echo e((isset($product_null_status) && $product_null_status == 1) ? 'disabled':''); ?>

                    type="button"><?php echo e(translate('proceed_to_next')); ?></button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/blunxtld/public_html/resources/themes/theme_aster/theme-views/partials/_order-summery.blade.php ENDPATH**/ ?>