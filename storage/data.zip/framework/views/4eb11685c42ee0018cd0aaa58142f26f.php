<span id="get-send-success-msg" data-text="<?php echo e(translate("send_successfully")); ?>"></span>
<span id="all-msg-container" data-afterextend="<?php echo e(translate('see_less')); ?>" data-seemore="<?php echo e(translate('see_more')); ?>"></span>
<span class="please_fill_out_this_field" data-text="<?php echo e(translate('please_fill_out_this_field')); ?>"></span>
<span class="redirecting-payment-message" data-text="<?php echo e(translate('redirecting_to_the_payment').'....'); ?>"></span>
<span id="successfully-copied" data-text="<?php echo e(translate('successfully_copied')); ?>"></span>
<span id="copied-failed" data-text="<?php echo e(translate('copied-failed').'!'); ?>"></span>
<span id="get-cancel-message" data-text="<?php echo e(translate('order_can_be_canceled_only_when_pending')); ?>"></span>
<span id="get-select-payment-method-message" data-text="<?php echo e(translate('please_select_a_payment_methods')); ?>"></span>
<span id="get-minus_value-message" data-text="<?php echo e(translate('cannot_input_minus_value')); ?>"></span>
<span id="get-check-password-msg"
      data-retype="<?php echo e(translate('please_retype_password')); ?>"
      data-not-match="<?php echo e(translate('Passwords_do_not_match').'!'); ?>"
      data-character-limit="<?php echo e(translate('password_must_be_8_Character').'.'); ?>"
      data-match="<?php echo e(translate('passwords_match').'.'); ?>">
</span>
<span id="get-resend-otp-text" data-success="<?php echo e(translate('OTP_has_been_sent_again.')); ?>" data-error="<?php echo e(translate('please_wait_for_new_code.')); ?>">

</span>
<?php /**PATH /home/blunxtld/public_html/resources/themes/theme_aster/theme-views/layouts/partials/_translate-text-for-js.blade.php ENDPATH**/ ?>