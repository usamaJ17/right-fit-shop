<?php use App\Utils\Helpers; ?>


<?php $__env->startSection('title', translate('my_Compare_List').' | '.$web_config['name']->value.' '.translate('ecommerce')); ?>

<?php $__env->startSection('content'); ?>
    <main class="main-content d-flex flex-column gap-3 py-3 mb-4">
        <div class="container">
            <div class="row g-3">
                <?php echo $__env->make('theme-views.partials._profile-aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-lg-9">
                    <div class="card h-100">
                        <div class="card-body p-lg-4">
                            <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
                                <h5 class="text-capitalize"><?php echo e(translate('my_compare_list')); ?></h5>
                                <div class="d-flex gap-4 flex-wrap">
                                    <?php if($compareLists->count()>0): ?>
                                        <a href="javascript:"
                                           class="btn-link text-danger text-capitalize delete-action text-capitalize"
                                           data-action="<?php echo e(route('product-compare.delete-all')); ?>"
                                           data-text="<?php echo e(translate('want_to_clear_all_compare_list').'?'); ?>">
                                            <?php echo e(translate('Clear_All')); ?>

                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="mt-4">
                                <div class="table-responsive">
                                    <table class="table align-middle table-bordered compare--table">
                                        <tbody>
                                        <?php if($compareLists->count()>0): ?>
                                            <tr>
                                                <th></th>
                                                <?php $__currentLoopData = $compareLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compareList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <th>
                                                        <div class="d-flex flex-column gap-1 align-items-center">
                                                            <img width="160" class="dark-support" alt=""
                                                                 src="<?php echo e(getValidImage(path: 'storage/app/public/product/thumbnail/'.$compareList->product['thumbnail'], type: 'product')); ?>">
                                                            <a href="javascript:"
                                                               data-action="<?php echo e(route('product-compare.delete', ['id'=>$compareList['id']])); ?>"
                                                               data-text="<?php echo e(translate('want_to_delete_this_item').'?'); ?>"
                                                               class="btn-link text-danger text-decoration-underline ">
                                                                <?php echo e(translate('remove')); ?>

                                                            </a>
                                                        </div>
                                                    </th>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                            <tr>
                                                <th><?php echo e(translate('Product_Name')); ?></th>
                                                <?php $__currentLoopData = $compareLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compareList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td>
                                                        <a href="<?php echo e(route('product',$compareList->product['slug'])); ?>">
                                                            <?php echo e($compareList->product['name']); ?>

                                                        </a>
                                                    </td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                            <tr>
                                                <th><?php echo e(translate('price')); ?></th>
                                                <?php $__currentLoopData = $compareLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compareList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td><?php echo e(Helpers::currency_converter($compareList->product['unit_price'])); ?></td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                            <tr>
                                                <th><?php echo e(translate('brand')); ?></th>
                                                <?php $__currentLoopData = $compareLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compareList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($web_config['brand_setting']): ?>
                                                        <?php if(isset($compareList->product->brand->image)): ?>
                                                            <td>
                                                                <a href="<?php echo e(route('products',['id'=> $compareList->product->brand['id'],'data_from'=>'brand','page'=>1])); ?>">
                                                                    <img width="48" class="rounded dark-support" alt=""
                                                                         src="<?php echo e(getValidimage(path: 'storage/app/public/brand/'.($compareList->product->brand->image), type:'brand')); ?>">
                                                                </a>
                                                            </td>
                                                        <?php else: ?>
                                                            <?php echo e(translate('non_brand_product')); ?>

                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                            <tr>
                                                <th><?php echo e(translate('category')); ?></th>
                                                <?php $__currentLoopData = $compareLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compareList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td>
                                                        <a href="<?php echo e(route('products',['id'=> $compareList->product['category_id'],'data_from'=>'category','page'=>1])); ?>">
                                                            <?php echo e($compareList?->product?->category?->name); ?>

                                                        </a>
                                                    </td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        <?php endif; ?>
                                        <?php if($compareLists->count()==0): ?>
                                            <tr>
                                                <td><h5 class="text-center"><?php echo e(translate('not_found_anything')); ?></h5>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme-views.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/blunxtld/public_html/resources/themes/theme_aster/theme-views/users-profile/account-compare-list.blade.php ENDPATH**/ ?>