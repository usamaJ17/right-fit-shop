<?php $__env->startSection('title', translate('About_Us').' | '.$web_config['name']->value.' '.translate('ecommerce')); ?>

<?php $__env->startPush('css_or_js'); ?>
    <meta property="og:image" content="<?php echo e(asset('storage/app/public/company')); ?>/<?php echo e($web_config['web_logo']->value); ?>"/>
    <meta property="og:title" content="About <?php echo e($web_config['name']->value); ?> "/>
    <meta property="og:url" content="<?php echo e(env('APP_URL')); ?>">
    <meta property="og:description"
          content="<?php echo e(substr(strip_tags(str_replace('&nbsp;', ' ', $web_config['about']->value)),0,160)); ?>">
    <meta property="twitter:card" content="<?php echo e(asset('storage/app/public/company')); ?>/<?php echo e($web_config['web_logo']->value); ?>"/>
    <meta property="twitter:title" content="about <?php echo e($web_config['name']->value); ?>"/>
    <meta property="twitter:url" content="<?php echo e(env('APP_URL')); ?>">
    <meta property="twitter:description"
          content="<?php echo e(substr(strip_tags(str_replace('&nbsp;', ' ', $web_config['about']->value)),0,160)); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <main class="main-content d-flex flex-column gap-3 pb-3">
        <div class="page-title overlay py-5 __opacity-half background-custom-fit"
             <?php if($pageTitleBanner): ?>
                 <?php if(File::exists(base_path('storage/app/public/banner/'.json_decode($pageTitleBanner['value'])->image))): ?>
                     data-bg-img="<?php echo e(asset('storage/app/public/banner/'.json_decode($pageTitleBanner['value'])->image)); ?>"
                 <?php else: ?>
                     data-bg-img="<?php echo e(theme_asset('assets/img/media/page-title-bg.png')); ?>"
                 <?php endif; ?>
             <?php else: ?>
                 data-bg-img="<?php echo e(theme_asset('assets/img/media/page-title-bg.png')); ?>"
            <?php endif; ?>
        >
            <div class="container">
                <h1 class="absolute-white text-center text-capitalize"><?php echo e(translate('about_our_company')); ?></h1>
            </div>
        </div>
        <div class="container">
            <div class="card my-4">
                <div class="card-body p-lg-4 text-dark page-paragraph">
                    <?php echo $aboutUs; ?>

                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme-views.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/blunxtld/public_html/resources/themes/theme_aster/theme-views/pages/about-us.blade.php ENDPATH**/ ?>