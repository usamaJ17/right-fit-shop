<?php $__env->startSection('title', translate('Personal_Details').' | '.$web_config['name']->value.' '.translate('ecommerce')); ?>
<?php $__env->startSection('content'); ?>
    <main class="main-content d-flex flex-column gap-3 py-3 mb-5">
        <div class="container">
            <div class="row g-3">
                <?php echo $__env->make('theme-views.partials._profile-aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-lg-9">
                    <div class="card h-100">
                        <div class="card-body p-lg-4">
                            <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
                                <h5><?php echo e(translate('edit_personal_details')); ?></h5>
                                <a href="<?php echo e(route('user-profile')); ?>" class="btn-link text-secondary d-flex align-items-baseline">
                                    <i class="bi bi-chevron-left fs-12"></i> <?php echo e(translate('go_back')); ?>

                                </a>
                            </div>
                            <div class="mt-4">
                                <form  action="<?php echo e(route('user-update')); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="row gy-4">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label class="text-capitalize" for="f_name2"><?php echo e(translate('first_name')); ?></label>
                                                <input type="text" id="f_name" class="form-control" value="<?php echo e($customerDetail['f_name']); ?>" name="f_name" placeholder="<?php echo e(translate('ex').':'.translate('jhon')); ?>">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label class="text-capitalize" for="l_name2"><?php echo e(translate('last_name')); ?></label>
                                                <input type="text" id="l_name" class="form-control" value="<?php echo e($customerDetail['l_name']); ?>" name="l_name" placeholder="<?php echo e(translate('ex').':'.translate('doe')); ?>">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="phone2"><?php echo e(translate('phone')); ?></label>
                                                <input type="text" id="phone" name="phone" class="form-control" value="<?php echo e($customerDetail['phone']); ?>" placeholder="<?php echo e(translate('ex').':'.'01xxxxxxxxx'); ?>">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="email2"><?php echo e(translate('email')); ?></label>
                                                <input type="email" id="email2" class="form-control" value="<?php echo e($customerDetail['email']); ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="password2"><?php echo e(translate('password')); ?></label>
                                                <div class="input-inner-end-ele">
                                                    <input type="password" minlength="6" id="password" class="form-control" name="password" placeholder="<?php echo e(translate('ex').':'.'7+'.translate('character')); ?>">
                                                    <i class="bi bi-eye-slash-fill togglePassword"></i>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label class="text-capitalize" for="confirm_password2"><?php echo e(translate('confirm_password')); ?></label>
                                                <div class="input-inner-end-ele">
                                                    <input type="password" minlength="6" id="confirm-password" name="confirm_password" class="form-control" placeholder="<?php echo e(translate('ex').':'.'7+'.translate('character')); ?>">
                                                    <i class="bi bi-eye-slash-fill togglePassword"></i>
                                                </div>
                                            </div>
                                            <div id='message'></div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label><?php echo e(translate('attachment')); ?></label>
                                                <div class="d-flex flex-column gap-3">
                                                    <div class="upload-file">
                                                        <input type="file" class="upload-file__input"  name="image" multiple aria-required="true" accept="image/*">
                                                        <div class="upload-file__img">
                                                            <div class="temp-img-box">
                                                                <div class="d-flex align-items-center flex-column gap-2">
                                                                    <i class="bi bi-upload fs-30"></i>
                                                                    <div class="fs-12 text-muted"><?php echo e(translate('change_your_profile')); ?></div>
                                                                </div>
                                                            </div>
                                                            <img src="#" class="dark-support img-fit-contain border" alt="" hidden="">
                                                        </div>
                                                    </div>

                                                    <div class="text-muted"><?php echo e(translate('image_ratio_should_be').'1:1'); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="d-flex justify-content-end gap-3">
                                                <button type="reset" class="btn btn-secondary"><?php echo e(translate('reset')); ?></button>
                                                <button type="submit" class="btn btn-primary text-capitalize"><?php echo e(translate('update_profile')); ?></button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('theme-views.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/blunxtld/public_html/resources/themes/theme_aster/theme-views/users-profile/profile/update-user-profile.blade.php ENDPATH**/ ?>