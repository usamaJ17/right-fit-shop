<?php $__env->startSection('title', translate('refer_&_Earn').' | '.$web_config['name']->value.' '.translate('ecommerce')); ?>
<?php $__env->startSection('content'); ?>
    <main class="main-content d-flex flex-column gap-3 py-3 mb-5">
        <div class="container">
            <div class="row g-3">
                <?php echo $__env->make('theme-views.partials._profile-aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-lg-9">
                    <div class="card h-100">
                        <div class="card-body p-lg-4">
                            <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
                                <h5 class="text-capitalize"><?php echo e(translate('refer_&_earn')); ?></h5>
                            </div>
                            <div class="mt-4">
                                <div class="refer_and_earn_section">

                                    <div class="d-flex justify-content-center align-items-center py-2 mb-3">
                                        <div class="banner-img">
                                            <img class="img-fluid" alt="" width="300"
                                                 src="<?php echo e(theme_asset('assets/img/icons/refer-and-earn.png')); ?>">
                                        </div>
                                    </div>

                                    <div class="mb-4">
                                        <h5 class="primary-heading mb-2"><?php echo e(translate('invite_your_friends_&_businesses')); ?></h5>
                                        <p class="secondary-heading"><?php echo e(translate('copy_your_code_and_share_your_friends')); ?></p>
                                    </div>

                                    <div class="row justify-content-center">
                                        <div class="col-md-10">
                                            <div class="d-m-flex align-items-center gap-3">
                                                <div class="refer_code_box flex-grow-1">
                                                    <div class="refer_code click-to-copy-code"
                                                         data-copy-code="<?php echo e($customer_detail->referral_code); ?>"><?php echo e($customer_detail->referral_code); ?></div>
                                                    <span class="click-to-copy-code" data-copy-code="<?php echo e($customer_detail->referral_code); ?>">
                                                        <img class="w-100" alt=""
                                                             src="<?php echo e(theme_asset('assets/img/icons/solar_copy-bold-duotone.png')); ?>">
                                                    </span>
                                                </div>

                                                <h4 class="share-icons-heading mt-3 text-capitalize"><?php echo e(translate('share_via')); ?></h4>
                                                <div class="d-flex justify-content-center align-items-center share-on-social">
                                                    <?php
                                                        $text = "Greetings,6Valley is the best e-commerce platform in the country.If you are new to this website dont forget to use " . $customer_detail->referral_code . " " ."as the referral code while sign up into 6valley.";
                                                        $link = url('/');
                                                    ?>
                                                    <a href="https://api.whatsapp.com/send?text=<?php echo e($text); ?>.<?php echo e($link); ?>" target="_blank">
                                                        <img src="<?php echo e(theme_asset('assets/img/icons/whatsapp.png')); ?>" alt="">
                                                    </a>
                                                    <a href="mailto:recipient@example.com?subject=Referral%20Code%20Text&body=<?php echo e($text); ?>%20Link:%20<?php echo e($link); ?>" target="_blank">
                                                        <img src="<?php echo e(theme_asset('assets/img/icons/gmail.png')); ?>" alt="">
                                                    </a>
                                                    <a href="javascript:"
                                                       class="click-to-copy-code" data-copy-code="<?php echo e(route('home')); ?>?referral_code=<?php echo e($customer_detail->referral_code); ?>">
                                                        <img src="<?php echo e(theme_asset('assets/img/icons/share.png')); ?>" alt="">
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="information-section col-md-10">
                                            <h4 class="text-bold d-flex align-items-center gap-1"> <span class="custom-info-icon">i</span> <?php echo e(translate('how_you_it_works').'?'); ?></h4>
                                            <ul>
                                                <li>
                                                    <span class="item-custom-index"><?php echo e(translate('1')); ?></span>
                                                    <span class="item-custom-text"><?php echo e(translate('invite_your_friends_&_businesses')); ?></span>
                                                </li>
                                                <li>
                                                    <span class="item-custom-index"><?php echo e(translate('2')); ?></span>
                                                    <span class="item-custom-text"><?php echo e(translate('they_register')); ?> <?php echo e($web_config['name']->value); ?> <?php echo e(translate('with_special_offer')); ?></span>
                                                </li>
                                                <li>
                                                    <span class="item-custom-index"><?php echo e(translate('3')); ?></span>
                                                    <span class="item-custom-text"><?php echo e(translate('you_made_your_earning')); ?></span>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme-views.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/blunxtld/public_html/resources/themes/theme_aster/theme-views/users-profile/refer-earn.blade.php ENDPATH**/ ?>