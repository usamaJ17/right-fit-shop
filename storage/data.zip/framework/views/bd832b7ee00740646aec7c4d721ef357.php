<?php
    use App\Models\Cart;
    use App\Models\CartShipping;
    use App\Models\ShippingType;
    use App\Utils\Helpers;
    use App\Utils\OrderManager;
    use App\Utils\ProductManager;
    use function App\Utils\get_shop_name;
    $shippingMethod = getWebConfig(name: 'shipping_method');
    $cart = Cart::where(['customer_id' => (auth('customer')->check() ? auth('customer')->id() : session('guest_id'))])->with(['seller','allProducts.category'])->get()->groupBy('cart_group_id');
?>
<div class="container">
    <h4 class="text-center mb-3 text-capitalize"><?php echo e(translate('cart_list')); ?></h4>
    <form action="javascript:">
        <div class="row gy-3">
            <div class="col-lg-8">
                <div class="card h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-center mb-30">
                            <ul class="cart-step-list">
                                <li class="current cursor-pointer get-view-by-onclick"
                                    data-link="<?php echo e(route('shop-cart')); ?>">
                                    <span><i class="bi bi-check2"></i></span> <?php echo e(translate('cart')); ?></li>
                                <li class="cursor-pointer text-capitalize" data-link="<?php echo e(route('checkout-details')); ?>">
                                    <span><i class="bi bi-check2"></i></span> <?php echo e(translate('shopping_details')); ?></li>
                                <li><span><i class="bi bi-check2"></i></span> <?php echo e(translate('payment')); ?></li>
                            </ul>
                        </div>
                        <?php if(count($cart)==0): ?>
                            <?php $physical_product = false; ?>
                        <?php endif; ?>

                        <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group_key=>$group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $physical_product = false;
                                foreach ($group as $row) {
                                    if ($row->product_type == 'physical') {
                                        $physical_product = true;
                                    }
                                }
                            ?>
                            <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart_key=>$cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($shippingMethod=='inhouse_shipping'): ?>
                                        <?php
                                            $admin_shipping = ShippingType::where('seller_id', 0)->first();
                                            $shipping_type = isset($admin_shipping) === true ? $admin_shipping->shipping_type : 'order_wise';
                                        ?>
                                <?php else: ?>
                                        <?php
                                        if ($cartItem->seller_is == 'admin') {
                                            $admin_shipping = ShippingType::where('seller_id', 0)->first();
                                            $shipping_type = isset($admin_shipping) === true ? $admin_shipping->shipping_type : 'order_wise';
                                        } else {
                                            $seller_shipping = ShippingType::where('seller_id', $cartItem->seller_id)->first();
                                            $shipping_type = isset($seller_shipping) === true ? $seller_shipping->shipping_type : 'order_wise';
                                        }
                                        ?>
                                <?php endif; ?>
                                <?php if($cart_key==0): ?>
                                    <?php
                                        $verify_status = OrderManager::minimum_order_amount_verify($request, $group_key);
                                    ?>
                                    <div class="bg-primary-light py-2 px-2 px-sm-3 mb-3 mb-sm-4">
                                        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
                                            <div class="d-flex align-items-center">
                                                <?php if($cartItem->seller_is=='admin'): ?>
                                                    <a href="<?php echo e(route('shopView',['id'=>0])); ?>">
                                                        <h5>
                                                            <?php echo e(getWebConfig(name: 'company_name')); ?>

                                                        </h5>
                                                    </a>
                                                <?php else: ?>
                                                    <a href="<?php echo e(route('shopView',['id'=>$cartItem->seller_id])); ?>">
                                                        <h5>
                                                            <?php echo e(get_shop_name($cartItem['seller_id'])); ?>

                                                        </h5>
                                                    </a>
                                                <?php endif; ?>
                                                <?php if($verify_status['minimum_order_amount'] > $verify_status['amount']): ?>
                                                    <span
                                                        class="ps-2 text-danger pulse-button minimum-order-amount-message"
                                                        data-bs-toggle="tooltip"
                                                        data-bs-placement="right"
                                                        data-bs-custom-class="custom-tooltip"
                                                        data-bs-title="<?php echo e(translate('minimum_Order_Amount')); ?> <?php echo e(Helpers::currency_converter($verify_status['minimum_order_amount'])); ?> <?php echo e(translate('for')); ?> <?php if($cartItem->seller_is=='admin'): ?> <?php echo e(getWebConfig(name: 'company_name')); ?> <?php else: ?> <?php echo e(get_shop_name($cartItem['seller_id'])); ?> <?php endif; ?>">
                                                    <i class="bi bi-info-circle"></i>
                                                </span>
                                                <?php endif; ?>
                                            </div>
                                            <?php if($physical_product && $shippingMethod=='sellerwise_shipping' && $shipping_type == 'order_wise'): ?>
                                                <?php
                                                    $choosen_shipping=CartShipping::where(['cart_group_id'=>$cartItem['cart_group_id']])->first()
                                                ?>

                                                <?php if(isset($choosen_shipping)===false): ?>
                                                    <?php $choosen_shipping['shipping_method_id']=0 ?>
                                                <?php endif; ?>
                                                <?php
                                                    $shippings=Helpers::get_shipping_methods($cartItem['seller_id'],$cartItem['seller_is'])
                                                ?>
                                                <?php if($physical_product && $shippingMethod=='sellerwise_shipping' && $shipping_type == 'order_wise'): ?>
                                                    <div class="border bg-white rounded custom-ps-3">
                                                        <div class="shiiping-method-btn d-flex gap-2 p-2 flex-wrap">
                                                            <div
                                                                class="flex-middle flex-nowrap fw-semibold text-dark gap-2">
                                                                <i class="bi bi-truck"></i>
                                                                <?php echo e(translate('Shipping_Method')); ?>:
                                                            </div>
                                                            <div class="dropdown">
                                                                <button type="button" class="border-0 bg-transparent d-flex gap-2 align-items-center dropdown-toggle text-dark p-0" data-bs-toggle="dropdown" aria-expanded="false">
                                                                        <?php
                                                                        $shippings_title = translate('choose_shipping_method');
                                                                        foreach ($shippings as $shipping) {
                                                                            if ($choosen_shipping['shipping_method_id'] == $shipping['id']) {
                                                                                $shippings_title = ucfirst($shipping['title']) . ' ( ' . $shipping['duration'] . ' ) ' . Helpers::currency_converter($shipping['cost']);
                                                                            }
                                                                        }
                                                                        ?>
                                                                    <?php echo e($shippings_title); ?>

                                                                </button>
                                                                <ul class="dropdown-menu dropdown-left-auto bs-dropdown-min-width--8rem">
                                                                    <?php $__currentLoopData = $shippings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <li class="cursor-pointer set-shipping-id" data-id="<?php echo e($shipping['id']); ?>" data-cart-group="<?php echo e($cartItem['cart_group_id']); ?>">
                                                                            <?php echo e($shipping['title'].' ( '.$shipping['duration'].' ) '.Helpers::currency_converter($shipping['cost'])); ?>

                                                                        </li>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div class="table-responsive d-none d-sm-block">
                                <?php
                                    $physical_product = false;
                                    foreach ($group as $row) {
                                        if ($row->product_type == 'physical') {
                                            $physical_product = true;
                                        }
                                    }
                                ?>
                                <table class="table align-middle">
                                    <thead class="table-light">
                                    <tr>
                                        <th class="border-0"><?php echo e(translate('product_details')); ?></th>
                                        <th class="border-0 text-center"><?php echo e(translate('qty')); ?></th>
                                        <th class="border-0 text-end"><?php echo e(translate('unit_price')); ?></th>
                                        <th class="border-0 text-end"><?php echo e(translate('discount')); ?></th>
                                        <th class="border-0 text-end"><?php echo e(translate('total')); ?></th>
                                        <?php if( $shipping_type != 'order_wise'): ?>
                                            <th class="border-0 text-end"><?php echo e(translate('shipping_cost')); ?> </th>
                                        <?php endif; ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart_key=>$cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php ($product = $cartItem->allProducts); ?>
                                        <tr>
                                            <td>
                                                <div class="media align-items-center gap-3">
                                                    <div
                                                        class="avatar avatar-xxl rounded border position-relative overflow-hidden">
                                                        <img alt="<?php echo e(translate('product')); ?>"
                                                            src="<?php echo e(getValidImage(path: 'storage/app/public/product/thumbnail/'.$cartItem['thumbnail'], type: 'product')); ?>"
                                                            class="dark-support img-fit rounded img-fluid overflow-hidden <?php echo e($product->status == 0?'blur-section':''); ?>">

                                                        <?php if($product->status == 0): ?>
                                                            <span class="temporary-closed position-absolute text-center p-2">
                                                                <span class="text-capitalize"><?php echo e(translate('not_available')); ?></span>
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div
                                                        class="media-body d-flex gap-1 flex-column <?php echo e($product->status == 0?'blur-section':''); ?>">
                                                        <h6 class="text-truncate text-capitalize width--20ch" >
                                                            <a href="<?php echo e($product->status == 1?route('product',$cartItem['slug']):'javascript:'); ?>"><?php echo e($cartItem['name']); ?></a>
                                                        </h6>
                                                        <?php $__currentLoopData = json_decode($cartItem['variations'],true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key1 =>$variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="fs-12"><?php echo e($key1); ?> : <?php echo e($variation); ?></div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="fs-12 text-capitalize"><?php echo e(translate('unit_price')); ?>

                                                            : <?php echo e(Helpers::currency_converter($cartItem['price'])); ?></div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="text-center">
                                                <?php if($product->status == 1): ?>
                                                    <div class="quantity quantity--style-two d-inline-flex">
                                                        <span
                                                            class="quantity__minus cart-qty-btn update-cart-quantity-list-cart-data"
                                                            data-min-order="<?php echo e($product->minimum_order_qty); ?>"
                                                            data-prevent=true
                                                            data-cart="<?php echo e($cartItem['id']); ?>" data-value="-1"
                                                            data-action="<?php echo e($cartItem['quantity'] == $product->minimum_order_qty ? 'delete':'minus'); ?>">
                                                            <i class="<?php echo e($cartItem['quantity'] == ($cartItem?->product?->minimum_order_qty ?? 1) ? 'bi bi-trash3-fill text-danger fs-10' : 'bi bi-dash'); ?>"></i>
                                                        </span>
                                                        <input type="text"
                                                               class="quantity__qty update-cart-quantity-list-cart-data-input"
                                                               value="<?php echo e($cartItem['quantity']); ?>" name="quantity"
                                                               id="cartQuantityWeb<?php echo e($cartItem['id']); ?>"
                                                               data-min-order="<?php echo e($product->minimum_order_qty); ?>"
                                                               data-cart="<?php echo e($cartItem['id']); ?>" data-value="0"
                                                               data-action=""
                                                               data-min="<?php echo e($cartItem?->product?->minimum_order_qty ?? 1); ?>">
                                                        <span
                                                            class="quantity__plus cart-qty-btn update-cart-quantity-list-cart-data"
                                                            data-prevent=true
                                                            data-min-order="<?php echo e($product->minimum_order_qty); ?>"
                                                            data-cart="<?php echo e($cartItem['id']); ?>" data-value="1"
                                                            data-action="">
                                                            <i class="bi bi-plus"></i>
                                                        </span>
                                                    </div>
                                                <?php else: ?>
                                                    <div class="quantity quantity--style-two d-inline-flex">
                                                        <span class="quantity__minus cartQuantity<?php echo e($cartItem['id']); ?> update-cart-quantity-list-cart-data"
                                                              data-min-order="<?php echo e($product->minimum_order_qty); ?>"
                                                              data-prevent=true
                                                              data-cart="<?php echo e($cartItem['id']); ?>" data-value="-1"
                                                              data-action="delete"
                                                              data-min="<?php echo e($cartItem['quantity']); ?>">
                                                            <i class="bi bi-trash3-fill text-danger fs-10"></i>
                                                        </span>
                                                        <input type="hidden"
                                                               class="quantity__qty cartQuantity<?php echo e($cartItem['id']); ?>"
                                                               value="1" name="quantity[<?php echo e($cartItem['id']); ?>]"
                                                               id="cartQuantity<?php echo e($cartItem['id']); ?>"
                                                               data-min="1">
                                                    </div>
                                                <?php endif; ?>

                                            </td>
                                            <td class="text-end"><?php echo e(Helpers::currency_converter($cartItem['price']*$cartItem['quantity'])); ?></td>
                                            <td class="text-end"><?php echo e(Helpers::currency_converter($cartItem['discount']*$cartItem['quantity'])); ?></td>
                                            <td class="text-end"><?php echo e(Helpers::currency_converter(($cartItem['price']-$cartItem['discount'])*$cartItem['quantity'])); ?></td>
                                            <td>
                                                <?php if( $shipping_type != 'order_wise'): ?>
                                                    <?php echo e(Helpers::currency_converter($cartItem['shipping_cost'])); ?>

                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                                <?php ($free_delivery_status = OrderManager::free_delivery_order_amount($group[0]->cart_group_id)); ?>

                                <?php if($free_delivery_status['status'] && (session()->missing('coupon_type') || session('coupon_type') !='free_delivery')): ?>
                                    <div class="free-delivery-area px-3 mb-3">
                                        <div class="d-flex align-items-center gap-2">
                                            <img
                                                src="<?php echo e(asset('public/assets/front-end/img/icons/free-shipping.png')); ?>"
                                                alt="<?php echo e(translate('image')); ?>" width="40">
                                            <?php if($free_delivery_status['amount_need'] <= 0): ?>
                                                <span
                                                    class="text-muted fs-16 text-capitalize"><?php echo e(translate('you_get_free_delivery_bonus')); ?></span>
                                            <?php else: ?>
                                                <span
                                                    class="need-for-free-delivery font-bold"><?php echo e(Helpers::currency_converter($free_delivery_status['amount_need'])); ?></span>
                                                <span
                                                    class="text-muted fs-16"><?php echo e(translate('add_more_for_free_delivery')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="progress free-delivery-progress">
                                            <div class="progress-bar" role="progressbar"
                                                 style="width: <?php echo e($free_delivery_status['percentage'] .'%'); ?>"
                                                 aria-valuenow="<?php echo e($free_delivery_status['percentage']); ?>"
                                                 aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="d-flex flex-column d-sm-none">
                                <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart_key=>$cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php ($product = $cartItem->allProducts); ?>
                                    <div
                                        class="border-bottom d-flex align-items-start justify-content-between gap-2 py-2">
                                        <div class="media gap-2">
                                            <div
                                                class="avatar avatar-lg rounded border position-relative overflow-hidden">
                                                <img
                                                    src="<?php echo e(getValidImage(path: 'storage/app/public/product/thumbnail/'.$cartItem['thumbnail'], type: 'product')); ?>"
                                                    class="dark-support img-fit rounded img-fluid overflow-hidden <?php echo e($product->status == 0?'blur-section':''); ?>"
                                                    alt="">
                                                <?php if($product->status == 0): ?>
                                                    <span class="temporary-closed position-absolute text-center p-2">
                                                <span><?php echo e(translate('N/A')); ?></span>
                                            </span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="media-body d-flex gap-1 flex-column <?php echo e($product->status == 0?'blur-section':''); ?>">
                                                <h6 class="text-truncate text-capitalize width--20ch">
                                                    <a href="<?php echo e(route('product',$cartItem['slug'])); ?>"><?php echo e($cartItem['name']); ?></a>
                                                </h6>
                                                <?php $__currentLoopData = json_decode($cartItem['variations'],true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key1 =>$variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="fs-12"><?php echo e($key1); ?> : <?php echo e($variation); ?></div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <div class="fs-12 text-capitalize"><?php echo e(translate('unit_price')); ?>

                                                    : <?php echo e(Helpers::currency_converter($cartItem['price']*$cartItem['quantity'])); ?></div>
                                                <div class="fs-12"><?php echo e(translate('discount')); ?>

                                                    : <?php echo e(Helpers::currency_converter($cartItem['discount']*$cartItem['quantity'])); ?></div>
                                                <div class="fs-12"><?php echo e(translate('total')); ?>

                                                    : <?php echo e(Helpers::currency_converter(($cartItem['price']-$cartItem['discount'])*$cartItem['quantity'])); ?></div>
                                                <?php if( $shipping_type != 'order_wise'): ?>
                                                    <div class="fs-12"><?php echo e(translate('shipping_cost')); ?>

                                                        : <?php echo e(Helpers::currency_converter($cartItem['shipping_cost'])); ?></div>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="quantity quantity--style-two flex-column d-inline-flex">
                                            <?php if($product->status == 1): ?>
                                                <span class="quantity__minus update-cart-quantity-mobile-list-cart-data"
                                                      data-min-order="<?php echo e($product->minimum_order_qty); ?>"
                                                      data-prevent=true
                                                      data-cart="<?php echo e($cartItem['id']); ?>" data-value="-1"
                                                      data-action="<?php echo e($cartItem['quantity'] == $product->minimum_order_qty ? 'delete':'minus'); ?>">
                                                    <i class="<?php echo e($cartItem['quantity'] == ($cartItem?->product?->minimum_order_qty ?? 1) ? 'bi bi-trash3-fill text-danger fs-10' : 'bi bi-dash'); ?>"></i>
                                                </span>
                                                <input type="text"
                                                       class="quantity__qty update-cart-quantity-list-mobile-cart-data-input"
                                                       value="<?php echo e($cartItem['quantity']); ?>" name="quantity"
                                                       id="cartQuantityMobile<?php echo e($cartItem['id']); ?>"
                                                       data-min-order="<?php echo e($product->minimum_order_qty); ?>"
                                                       data-cart="<?php echo e($cartItem['id']); ?>" data-value="0"
                                                       data-action="">
                                                <span class="quantity__plus update-cart-quantity-list-mobile-cart-data"
                                                      data-prevent=true
                                                      data-min-order="<?php echo e($product->minimum_order_qty); ?>"
                                                      data-cart="<?php echo e($cartItem['id']); ?>" data-value="1"
                                                      data-action="">
                                                    <i class="bi bi-plus"></i>
                                                </span>
                                            <?php else: ?>
                                                <span class="quantity__minus update-cart-quantity-list-mobile-cart-data"
                                                      data-prevent=true
                                                      data-min-order="<?php echo e($product->minimum_order_qty); ?>"
                                                      data-cart="<?php echo e($cartItem['id']); ?>" data-value="-1"
                                                      data-action="<?php echo e($cartItem['quantity'] == $product->minimum_order_qty ? 'delete':'minus'); ?>">
                                                        <i class="bi bi-trash3-fill text-danger fs-10"></i>
                                                </span>
                                                <input type="hidden"
                                                       class="quantity__qty cartQuantity<?php echo e($cartItem['id']); ?>"
                                                       data-min-order="<?php echo e($product->minimum_order_qty ?? 1); ?>"
                                                       data-cart="<?php echo e($cartItem['id']); ?>" data-value="0" data-action=""
                                                       value="<?php echo e($cartItem['quantity']); ?>" name="quantity"
                                                       id="cartQuantityMobile<?php echo e($cartItem['id']); ?>"
                                                       data-min="<?php echo e($cartItem['quantity']); ?>">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php ($free_delivery_status = OrderManager::free_delivery_order_amount($group[0]->cart_group_id)); ?>

                                <?php if($free_delivery_status['status'] && (session()->missing('coupon_type') || session('coupon_type') !='free_delivery')): ?>
                                    <div class="free-delivery-area px-3 mb-3">
                                        <div class="d-flex align-items-center gap-3">
                                            <img
                                                src="<?php echo e(asset('public/assets/front-end/img/icons/free-shipping.png')); ?>"
                                                alt="" width="40">
                                            <?php if($free_delivery_status['amount_need'] <= 0): ?>
                                                <span
                                                    class="text-muted fs-16"><?php echo e(translate('you_Get_Free_Delivery_Bonus')); ?></span>
                                            <?php else: ?>
                                                <span
                                                    class="need-for-free-delivery font-bold"><?php echo e(Helpers::currency_converter($free_delivery_status['amount_need'])); ?></span>
                                                <span
                                                    class="text-muted fs-16"><?php echo e(translate('add_more_for_free_delivery')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="progress free-delivery-progress">
                                            <div class="progress-bar" role="progressbar"
                                                 style="width: <?php echo e($free_delivery_status['percentage'] .'%'); ?>"
                                                 aria-valuenow="<?php echo e($free_delivery_status['percentage']); ?>"
                                                 aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php if($shippingMethod=='inhouse_shipping'): ?>
                                <?php
                                $physical_product = false;
                                foreach ($cart as $group_key => $group) {
                                    foreach ($group as $row) {
                                        if ($row->product_type == 'physical') {
                                            $physical_product = true;
                                        }
                                    }
                                }
                                ?>

                                <?php
                                $admin_shipping = ShippingType::where('seller_id', 0)->first();
                                $shipping_type = isset($admin_shipping) === true ? $admin_shipping->shipping_type : 'order_wise';
                                ?>
                            <?php if($shipping_type == 'order_wise' && $physical_product): ?>
                                <?php ($shippings=Helpers::get_shipping_methods(1,'admin')); ?>
                                <?php ($choosen_shipping=CartShipping::where(['cart_group_id'=>$cartItem['cart_group_id']])->first()); ?>

                                <?php if(isset($choosen_shipping)===false): ?>
                                    <?php ($choosen_shipping['shipping_method_id']=0); ?>
                                <?php endif; ?>
                                <div class="row">
                                    <div class="col-12">
                                        <select class="form-control text-dark set-shipping-onchange">
                                            <option><?php echo e(translate('choose_shipping_method')); ?></option>
                                            <?php $__currentLoopData = $shippings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option
                                                    value="<?php echo e($shipping['id']); ?>" <?php echo e($choosen_shipping['shipping_method_id']==$shipping['id']?'selected':''); ?>>
                                                    <?php echo e($shipping['title'].' ( '.$shipping['duration'].' ) '.Helpers::currency_converter($shipping['cost'])); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>

                        <?php if( $cart->count() == 0): ?>
                            <div class="d-flex justify-content-center align-items-center">
                                <h4 class="text-danger text-capitalize"><?php echo e(translate('cart_empty')); ?></h4>
                            </div>
                        <?php endif; ?>

                        <form method="get">
                            <div class="form-group mt-3">
                                <div class="row">
                                    <div class="col-12">
                                        <label for="order-note"
                                               class="form-label input-label"><?php echo e(translate('order_note')); ?> <span
                                                class="input-label-secondary">(<?php echo e(translate('optional')); ?>)</span></label>
                                        <textarea class="form-control w-100" rows="5" id="order-note"
                                                  name="order_note"><?php echo e(session('order_note')); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('theme-views.partials._order-summery', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </form>
</div>
<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(theme_asset('assets/js/cart.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php /**PATH /home/blunxtld/public_html/resources/themes/theme_aster/theme-views/cart/cart-details.blade.php ENDPATH**/ ?>