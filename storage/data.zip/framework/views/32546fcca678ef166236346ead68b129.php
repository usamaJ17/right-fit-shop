<?php use App\Utils\Helpers; ?>


<?php $__env->startSection('title', translate('Payment_Details').' | '.$web_config['name']->value.' '.translate('ecommerce')); ?>

<?php $__env->startSection('content'); ?>
    <main class="main-content d-flex flex-column gap-3 py-3 mb-5">
        <div class="container">
            <h4 class="text-center mb-3 text-capitalize"><?php echo e(translate('payment_details')); ?></h4>
            <div class="row">
                <div class="col-lg-8 mb-3 mb-lg-0">
                    <div class="card h-100">
                        <div class="card-body  px-sm-4">
                            <div class="d-flex justify-content-center mb-30">
                                <ul class="cart-step-list">
                                    <li class="done cursor-pointer get-view-by-onclick"
                                        data-link="<?php echo e(route('shop-cart')); ?>">
                                        <span><i class="bi bi-check2"></i></span> <?php echo e(translate('cart')); ?>

                                    </li>
                                    <li class="done cursor-pointer get-view-by-onclick text-capitalize"
                                        data-link="<?php echo e(route('checkout-details')); ?>">
                                        <span><i class="bi bi-check2"></i></span> <?php echo e(translate('shipping_details')); ?>

                                    </li>
                                    <li class="current"><span><i
                                                class="bi bi-check2"></i></span> <?php echo e(translate('payment')); ?></li>
                                </ul>
                            </div>
                            <h5 class="mb-4 text-capitalize"><?php echo e(translate('payment_information')); ?></h5>
                            <div class="mb-30">
                                <ul class="option-select-btn flex-wrap gap-3">
                                    <?php if(!$cod_not_show && $cash_on_delivery['status']): ?>
                                        <li>
                                            <form action="<?php echo e(route('checkout-complete')); ?>" method="get">
                                                <label>
                                                    <input type="hidden" name="payment_method" value="cash_on_delivery">
                                                    <button type="submit"
                                                            class="payment-method d-flex border-0 align-items-center gap-3 overflow-hidden">
                                                        <img width="32" class="dark-support" alt=""
                                                             src="<?php echo e(theme_asset('assets/img/icons/cash-on.png')); ?>">
                                                        <span class="text-capitalize"><?php echo e(translate('cash_on_delivery')); ?></span>
                                                    </button>
                                                </label>
                                            </form>
                                        </li>
                                    <?php endif; ?>
                                    <?php if($digital_payment['status']==1): ?>
                                        <?php if(auth('customer')->check() && $wallet_status==1): ?>
                                            <li>
                                                <label class="">
                                                    <button
                                                        class="payment-method d-flex align-iems-center border-0 gap-3 overflow-hidden"
                                                        type="submit" data-bs-toggle="modal"
                                                        data-bs-target="#wallet_submit_button">
                                                        <img width="30"
                                                             src="<?php echo e(theme_asset('assets/img/icons/wallet.png')); ?>"
                                                             class="dark-support" alt="">
                                                        <span><?php echo e(translate('wallet')); ?></span>
                                                    </button>
                                                </label>
                                            </li>
                                        <?php endif; ?>
                                        <li class="<?php echo e(((($payment_gateway_published_status == 1 && count($payment_gateways_list) == 0) && (!isset($offline_payment) && !$offline_payment['status']))? 'd-none':'')); ?>">
                                            <label id="digital-payment-btn">
                                                <input type="hidden">
                                                <span class="payment-method d-flex align-iems-center gap-3">
                                                <img width="30"
                                                     src="<?php echo e(theme_asset('assets/img/icons/degital-payment.png')); ?>"
                                                     class="dark-support" alt="">
                                                <span><?php echo e(translate('Digital_Payment')); ?></span>
                                            </span>
                                            </label>
                                        </li>
                                        <?php $__currentLoopData = $payment_gateways_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_gateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <form method="post" class="digital-payment d--none"
                                                      action="<?php echo e(route('customer.web-payment-request')); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="user_id"
                                                           value="<?php echo e(auth('customer')->check() ? auth('customer')->id() : session('guest_id')); ?>">
                                                    <input type="hidden" name="customer_id"
                                                           value="<?php echo e(auth('customer')->check() ? auth('customer')->id() : session('guest_id')); ?>">
                                                    <input type="hidden" name="payment_method"
                                                           value="<?php echo e($payment_gateway->key_name); ?>">
                                                    <input type="hidden" name="payment_platform" value="web">
                                                    <?php if($payment_gateway->mode == 'live' && isset($payment_gateway->live_values['callback_url'])): ?>
                                                        <input type="hidden" name="callback"
                                                               value="<?php echo e($payment_gateway->live_values['callback_url']); ?>">
                                                    <?php elseif($payment_gateway->mode == 'test' && isset($payment_gateway->test_values['callback_url'])): ?>
                                                        <input type="hidden" name="callback"
                                                               value="<?php echo e($payment_gateway->test_values['callback_url']); ?>">
                                                    <?php else: ?>
                                                        <input type="hidden" name="callback" value="">
                                                    <?php endif; ?>
                                                    <input type="hidden" name="external_redirect_link"
                                                           value="<?php echo e(url('/').'/web-payment'); ?>">
                                                    <label>
                                                        <?php ($additional_data = $payment_gateway['additional_data'] != null ? json_decode($payment_gateway['additional_data']) : []); ?>
                                                        <button
                                                            class="payment-method border-0 d-flex align-iems-center gap-3 digital-payment-card overflow-hidden"
                                                            type="submit">
                                                            <img width="100" class="dark-support" alt=""
                                                                 src="<?php echo e(getValidImage(path: 'storage/app/public/payment_modules/gateway_image/'.($additional_data != null ? $additional_data->gateway_image : ''), type:'banner')); ?>">
                                                        </button>
                                                    </label>
                                                </form>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($offline_payment) && $offline_payment['status']): ?>
                                            <li>
                                                <form action="<?php echo e(route('offline-payment-checkout-complete')); ?>"
                                                      method="get" class="digital-payment d--none">
                                                    <label>
                                                        <input type="hidden" name="weight">
                                                        <span
                                                            class="payment-method d-flex align-iems-center gap-3 overflow-hidden"
                                                            data-bs-toggle="modal"
                                                            data-bs-target="#offline_payment_submit_button">
                                                            <img width="100"
                                                                 src="<?php echo e(theme_asset('assets/img/payment/pay-offline.png')); ?>"
                                                                 class="dark-support" alt="">
                                                        </span>
                                                    </label>
                                                </form>
                                            </li>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </ul>
                                <?php if($digital_payment['status']==1): ?>
                                    <?php if(auth('customer')->check() && $wallet_status==1): ?>
                                        <div class="modal fade" id="wallet_submit_button">
                                            <div class="modal-dialog modal-dialog-centered">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title"
                                                            id="exampleModalLongTitle"><?php echo e(translate('wallet_payment')); ?></h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                                aria-label="Close"></button>
                                                    </div>
                                                    <?php ($customer_balance = auth('customer')->user()->wallet_balance); ?>
                                                    <?php ($remain_balance = $customer_balance - $amount); ?>
                                                    <form action="<?php echo e(route('checkout-complete-wallet')); ?>" method="get"
                                                          class="needs-validation">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="modal-body">
                                                            <div class="form-row">
                                                                <div class="form-group col-12">
                                                                    <label
                                                                        for=""><?php echo e(translate('your_current_balance')); ?></label>
                                                                    <input class="form-control" type="text"
                                                                           value="<?php echo e(Helpers::currency_converter($customer_balance)); ?>"
                                                                           readonly>
                                                                </div>
                                                            </div>

                                                            <div class="form-row">
                                                                <div class="form-group col-12">
                                                                    <label
                                                                        for=""><?php echo e(translate('order_amount')); ?></label>
                                                                    <input class="form-control" type="text"
                                                                           value="<?php echo e(Helpers::currency_converter($amount)); ?>"
                                                                           readonly>
                                                                </div>
                                                            </div>
                                                            <div class="form-row">
                                                                <div class="form-group col-12">
                                                                    <label
                                                                        for=""><?php echo e(translate('remaining_balance')); ?></label>
                                                                    <input class="form-control" type="text"
                                                                           value="<?php echo e(Helpers::currency_converter($remain_balance)); ?>"
                                                                           readonly>
                                                                    <?php if($remain_balance<0): ?>
                                                                        <label
                                                                            class="__color-crimson"><?php echo e(translate('you_do_not_have_sufficient_balance_for_pay_this_order')); ?>

                                                                            !!</label>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>

                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button"
                                                                    class="update_cart_button fs-16 btn btn-secondary"
                                                                    data-dismiss="modal"><?php echo e(translate('close')); ?></button>
                                                            <button type="submit"
                                                                    class="update_cart_button fs-16 btn btn-primary" <?php echo e($remain_balance>0? '':'disabled'); ?>><?php echo e(translate('submit')); ?></button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if(isset($offline_payment) && $offline_payment['status']): ?>
                                        <div class="modal fade" id="offline_payment_submit_button">
                                            <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title"
                                                            id="exampleModalLongTitle"><?php echo e(translate('offline_Payment')); ?></h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                                aria-label="Close"></button>
                                                    </div>
                                                    <form action="<?php echo e(route('offline-payment-checkout-complete')); ?>"
                                                          method="post" class="needs-validation">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="modal-body p-3 p-md-5">

                                                            <div class="text-center px-5">
                                                                <img
                                                                    src="<?php echo e(theme_asset('assets/img/offline-payments.png')); ?>"
                                                                    alt="">
                                                                <p class="py-2">
                                                                    <?php echo e(translate('pay_your_bill_using_any_of_the_payment_method_below_and_input_the_required_information_in_the_form')); ?>

                                                                </p>
                                                            </div>

                                                            <div class="">

                                                                <select class="form-select" id="pay-offline-method"
                                                                        name="payment_by" required>
                                                                    <option
                                                                        value=""><?php echo e(translate('select_Payment_Method')); ?></option>
                                                                    <?php $__currentLoopData = $offline_payment_methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($method->id); ?>"><?php echo e(translate('payment_Method').':'); ?><?php echo e($method->method_name); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>

                                                            <div class="" id="method-filed-div">
                                                                <div class="text-center py-5">
                                                                    <img class="pt-5"
                                                                         src="<?php echo e(theme_asset('assets/img/offline-payments-vectors.png')); ?>"
                                                                         alt="">
                                                                    <p class="py-2 pb-5 text-muted"><?php echo e(translate('select_a_payment_method first')); ?></p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php echo $__env->make('theme-views.partials._order-summery', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </main>
    <span class="get-payment-method-list" data-action="<?php echo e(route('pay-offline-method-list')); ?>"></span>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(theme_asset('assets/js/payment-page.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('theme-views.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/blunxtld/public_html/resources/themes/theme_aster/theme-views/checkout/payment.blade.php ENDPATH**/ ?>