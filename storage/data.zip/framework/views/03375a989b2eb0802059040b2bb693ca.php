<?php $__env->startSection('title', $web_config['name']->value.' '.translate('Online_Shopping').' | '.$web_config['name']->value.' '.translate('ecommerce')); ?>
<?php $__env->startPush('css_or_js'); ?>
    <meta property="og:image" content="<?php echo e(asset('storage/app/public/company')); ?>/<?php echo e($web_config['web_logo']->value); ?>"/>
    <meta property="og:title" content="Welcome To <?php echo e($web_config['name']->value); ?> Home"/>
    <meta property="og:url" content="<?php echo e(env('APP_URL')); ?>">
    <meta property="og:description" content="<?php echo e(substr(strip_tags(str_replace('&nbsp;', ' ', $web_config['about']->value)),0,160)); ?>">

    <meta property="twitter:card" content="<?php echo e(asset('storage/app/public/company')); ?>/<?php echo e($web_config['web_logo']->value); ?>"/>
    <meta property="twitter:title" content="Welcome To <?php echo e($web_config['name']->value); ?> Home"/>
    <meta property="twitter:url" content="<?php echo e(env('APP_URL')); ?>">
    <meta property="twitter:description" content="<?php echo e(substr(strip_tags(str_replace('&nbsp;', ' ', $web_config['about']->value)),0,160)); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <main class="main-content d-flex flex-column gap-3 py-3">
        <?php echo $__env->make('theme-views.partials._main-banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php if($web_config['flash_deals']): ?>
            <?php echo $__env->make('theme-views.partials._flash-deals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <?php echo $__env->make('theme-views.partials._find-what-you-need', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php if($web_config['business_mode'] == 'multi' && count($top_sellers) > 0): ?>
            <?php echo $__env->make('theme-views.partials._top-stores', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <?php if($web_config['featured_deals']->count() > 0 && $featured_deals->count() > 0 ): ?>
            <?php echo $__env->make('theme-views.partials._featured-deals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <?php echo $__env->make('theme-views.partials._recommended-product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if($web_config['business_mode'] == 'multi'): ?>
            <?php echo $__env->make('theme-views.partials._more-stores', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <?php echo $__env->make('theme-views.partials._top-rated-products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('theme-views.partials._best-deal-just-for-you', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('theme-views.partials._home-categories', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if(!empty($main_section_banner)): ?>
        <section class="">
            <div class="container">
                <div class="py-5 rounded position-relative">
                    <img src="<?php echo e(getValidImage(path: 'storage/app/public/banner/'.($main_section_banner ? $main_section_banner['photo'] : ''), type:'banner')); ?>"
                         alt="" class="rounded position-absolute dark-support img-fit start-0 top-0 index-n1 flipX-in-rtl">
                    <div class="row justify-content-center">
                        <div class="col-10 py-4">
                            <h6 class="text-primary mb-2 text-capitalize"><?php echo e(translate('do_not_miss_today`s_deal')); ?>!</h6>
                            <h2 class="fs-2 mb-4 absolute-dark text-capitalize"><?php echo e(translate('let_us_shopping_today')); ?></h2>
                            <div class="d-flex">
                                <a href="<?php echo e($main_section_banner ? $main_section_banner->url:''); ?>" class="btn btn-primary fs-16 text-capitalize"><?php echo e(translate('shop_now')); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php endif; ?>
    </main>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('theme-views.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/blunxtld/public_html/resources/themes/theme_aster/theme-views/home.blade.php ENDPATH**/ ?>