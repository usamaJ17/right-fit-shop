<?php $__env->startSection('title', __('Not Found')); ?>

<?php $__env->startSection('message'); ?>
    <div class="container">
        <div class="row justify-content-center align-items-center vh-100">
            <div class="col-12">
                <div class="text-primary text-center">
                    <img src="<?php echo e(asset("public/assets/front-end/png/500.png")); ?>" alt="" class="img-fluid">
                </div>

                <p class="text-center h4 lead py-2">
                    <?php echo e(translate('We_are_sorry_server_is_not_responding')); ?>

                    <br>
                    <?php echo e(translate('Try_after_sometime')); ?>

                </p>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/blunxtld/public_html/resources/views/errors/500.blade.php ENDPATH**/ ?>