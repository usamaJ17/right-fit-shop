<?php $__env->startSection('title', translate('Refund_Policy').' | '.$web_config['name']->value.' '.translate('ecommerce')); ?>

<?php $__env->startSection('content'); ?>
    <main class="main-content d-flex flex-column gap-3 pb-3">
        <div class="page-title overlay py-5 __opacity-half background-custom-fit"
             <?php if($pageTitleBanner): ?>
                 <?php if(File::exists(base_path('storage/app/public/banner/'.json_decode($pageTitleBanner['value'])->image))): ?>
                     data-bg-img="<?php echo e(asset('storage/app/public/banner/'.json_decode($pageTitleBanner['value'])->image)); ?>"
             <?php else: ?>
                 data-bg-img="<?php echo e(theme_asset('assets/img/media/page-title-bg.png')); ?>"
             <?php endif; ?>
             <?php else: ?>
                 data-bg-img="<?php echo e(theme_asset('assets/img/media/page-title-bg.png')); ?>"
            <?php endif; ?>
        >
            <div class="container">
                <h1 class="absolute-white text-center text-capitalize"><?php echo e(translate('refund_policy')); ?></h1>
            </div>
        </div>
        <div class="container">
            <div class="card my-4">
                <div class="card-body p-lg-4 text-dark page-paragraph">
                    <?php echo $refundPolicy['content']; ?>

                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme-views.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/blunxtld/public_html/resources/themes/theme_aster/theme-views/pages/refund-policy.blade.php ENDPATH**/ ?>