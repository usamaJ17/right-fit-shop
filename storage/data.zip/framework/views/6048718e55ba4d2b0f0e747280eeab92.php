<?php use App\Utils\Helpers;use App\Utils\ProductManager; ?>


<?php $__env->startSection('title', $product['name'].' | '.$web_config['name']->value.' '.translate('ecommerce')); ?>

<?php $__env->startPush('css_or_js'); ?>
    <meta name="description" content="<?php echo e($product->slug); ?>">
    <meta name="keywords" content="<?php $__currentLoopData = explode(' ',$product['name']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($keyword.' , '); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>">
    <?php if($product->added_by=='seller'): ?>
        <meta name="author" content="<?php echo e($product->seller->shop?$product->seller->shop->name:$product->seller->f_name); ?>">
    <?php elseif($product->added_by=='admin'): ?>
        <meta name="author" content="<?php echo e($web_config['name']->value); ?>">
    <?php endif; ?>
    <?php if($product['meta_image']): ?>
        <meta property="og:image" content="<?php echo e(asset("storage/app/public/product/meta")); ?>/<?php echo e($product->meta_image); ?>"/>
        <meta property="twitter:card"
              content="<?php echo e(asset("storage/app/public/product/meta")); ?>/<?php echo e($product->meta_image); ?>"/>
    <?php else: ?>
        <meta property="og:image" content="<?php echo e(asset("storage/app/public/product/thumbnail")); ?>/<?php echo e($product->thumbnail); ?>"/>
        <meta property="twitter:card"
              content="<?php echo e(asset("storage/app/public/product/thumbnail/")); ?>/<?php echo e($product->thumbnail); ?>"/>
    <?php endif; ?>

    <?php if($product['meta_title']): ?>
        <meta property="og:title" content="<?php echo e($product->meta_title); ?>"/>
        <meta property="twitter:title" content="<?php echo e($product->meta_title); ?>"/>
    <?php else: ?>
        <meta property="og:title" content="<?php echo e($product->name); ?>"/>
        <meta property="twitter:title" content="<?php echo e($product->name); ?>"/>
    <?php endif; ?>
    <meta property="og:url" content="<?php echo e(route('product',[$product->slug])); ?>">

    <?php if($product['meta_description']): ?>
        <meta property="twitter:description" content="<?php echo $product['meta_description']; ?>">
        <meta property="og:description" content="<?php echo $product['meta_description']; ?>">
    <?php else: ?>
        <meta property="og:description"
              content="<?php $__currentLoopData = explode(' ',$product['name']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($keyword.' , '); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>">
        <meta property="twitter:description"
              content="<?php $__currentLoopData = explode(' ',$product['name']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($keyword.' , '); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>">
    <?php endif; ?>
    <meta property="twitter:url" content="<?php echo e(route('product',[$product->slug])); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <main class="main-content d-flex flex-column gap-3 pt-3 mb-sm-5">
        <div class="container">
            <div class="row gx-3 gy-4">
                <div class="col-lg-8 col-xl-9">
                    <div class="card mb-3">
                        <div class="card-body">
                            <div class="quickview-content">
                                <div class="row gy-4">
                                    <div class="col-lg-5">
                                        <div class="pd-img-wrap position-relative h-100">
                                            <div
                                                class="swiper-container quickviewSlider2 border rounded aspect-1 border--gray">
                                                <div class="product__actions d-flex flex-column gap-2">
                                                    <a class="btn-wishlist add-to-wishlist cursor-pointer wishlist-<?php echo e($product['id']); ?> <?php echo e(($wishlistStatus == 1?'wishlist_icon_active':'')); ?>"
                                                       data-action="<?php echo e(route('store-wishlist')); ?>"
                                                       data-product-id="<?php echo e($product['id']); ?>"
                                                       id="wishlist-<?php echo e($product['id']); ?>"
                                                       title="<?php echo e(translate('add_to_wishlist')); ?>">
                                                        <i class="bi bi-heart"></i>
                                                    </a>
                                                    <a id="compare_list-<?php echo e($product['id']); ?>"
                                                       class="btn-compare stopPropagation add-to-compare compare_list-<?php echo e($product['id']); ?> <?php echo e(($compareList == 1?'compare_list_icon_active':'')); ?>"
                                                       data-action="<?php echo e(route('product-compare.index')); ?>"
                                                       data-product-id="<?php echo e($product['id']); ?>"
                                                       title="<?php echo e(translate('add_to_wishlist')); ?>">
                                                        <i class="bi bi-repeat"></i>
                                                    </a>
                                                    <div class="product-share-icons">
                                                        <a href="javascript:" title="Share">
                                                            <i class="bi bi-share-fill"></i>
                                                        </a>
                                                        <ul>
                                                            <li>
                                                                <a href="javascript:" class="share-on-social-media"
                                                                   data-action="<?php echo e(route('product',$product->slug)); ?>"
                                                                   data-social-media-name="facebook.com/sharer/sharer.php?u=">
                                                                    <i class="bi bi-facebook"></i>
                                                                </a>
                                                            </li>
                                                            <li>
                                                                <a href="javascript:"
                                                                   class="share-on-social-media"
                                                                   data-action="<?php echo e(route('product',$product->slug)); ?>"
                                                                   data-social-media-name="twitter.com/intent/tweet?text=">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="12"
                                                                         height="12" fill="currentColor"
                                                                         class="bi bi-twitter-x" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M12.6.75h2.454l-5.36 6.142L16 15.25h-4.937l-3.867-5.07-4.425 5.07H.316l5.733-6.57L0 .75h5.063l3.495 4.633L12.601.75Zm-.86 13.028h1.36L4.323 2.145H2.865l8.875 11.633Z"/>
                                                                    </svg>
                                                                </a>
                                                            </li>
                                                            <li>
                                                                <a href="javascript:"
                                                                   class="share-on-social-media"
                                                                   data-action="<?php echo e(route('product',$product->slug)); ?>"
                                                                   data-social-media-name="linkedin.com/shareArticle?mini=true&url=">
                                                                    <i class="bi bi-linkedin"></i>
                                                                </a>
                                                            </li>
                                                            <li>
                                                                <a href="javascript:"
                                                                   class="share-on-social-media"
                                                                   data-action="<?php echo e(route('product',$product->slug)); ?>"
                                                                   data-social-media-name="api.whatsapp.com/send?text=">
                                                                    <i class="bi bi-whatsapp"></i>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>

                                                <?php if($product->images!=null && json_decode($product->images)>0): ?>
                                                    <div class="swiper-wrapper">
                                                        <?php if(json_decode($product->colors) && $product->color_image): ?>
                                                            <?php $__currentLoopData = json_decode($product->color_image); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($photo->color != null): ?>
                                                                    <div class="swiper-slide position-relative"
                                                                         id="preview-box-<?php echo e($photo->color); ?>">
                                                                        <?php if($product->discount > 0 && $product->discount_type === "percent"): ?>
                                                                            <span class="product__discount-badge">
                                                                                <span>
                                                                                    <?php echo e('-'.$product->discount.'%'); ?>

                                                                                </span>
                                                                            </span>
                                                                        <?php elseif($product->discount > 0): ?>
                                                                            <span class="product__discount-badge">
                                                                                <span>
                                                                                    <?php echo e('-'.Helpers::currency_converter($product->discount)); ?>

                                                                                </span>
                                                                            </span>
                                                                        <?php endif; ?>

                                                                        <div class="easyzoom easyzoom--overlay">
                                                                            <a href="<?php echo e(getValidImage(path: 'storage/app/public/product/'.$photo->image_name, type:'product')); ?>">
                                                                                <img class="dark-support rounded" alt=""
                                                                                    src="<?php echo e(getValidImage(path: 'storage/app/public/product/'.$photo->image_name, type:'product')); ?>">
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                <?php else: ?>
                                                                    <div class="swiper-slide position-relative"
                                                                         id="preview-box-<?php echo e($photo->color); ?>">
                                                                        <?php if($product->discount > 0 && $product->discount_type === "percent"): ?>
                                                                            <span class="product__discount-badge">
                                                                                <span>
                                                                                    <?php echo e('-'.$product->discount.'%'); ?>

                                                                                </span>
                                                                            </span>
                                                                        <?php elseif($product->discount > 0): ?>
                                                                            <span class="product__discount-badge">
                                                                                    -<?php echo e(Helpers::currency_converter($product->discount)); ?>

                                                                                </span>
                                                                        <?php endif; ?>
                                                                        <div class="easyzoom easyzoom--overlay">
                                                                            <a href="<?php echo e(getValidImage(path: 'storage/app/public/product/'.$photo->image_name, type:'product')); ?>">
                                                                                <img class="dark-support rounded" alt=""
                                                                                    src="<?php echo e(getValidImage(path: 'storage/app/public/product/'.$photo->image_name, type:'product')); ?>">
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php else: ?>
                                                            <?php $__currentLoopData = json_decode($product->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <div class="swiper-slide position-relative">
                                                                    <?php if($product->discount > 0 && $product->discount_type === "percent"): ?>
                                                                        <span class="product__discount-badge">
                                                                            <span>
                                                                                -<?php echo e($product->discount); ?>%
                                                                            </span>
                                                                        </span>
                                                                    <?php elseif($product->discount > 0): ?>
                                                                        <span class="product__discount-badge">
                                                                            <span>
                                                                                <?php echo e('-'.Helpers::currency_converter($product->discount)); ?>

                                                                            </span>
                                                                        </span>
                                                                    <?php endif; ?>
                                                                    <div class="easyzoom easyzoom--overlay">
                                                                        <a href="<?php echo e(getValidImage(path: 'storage/app/public/product/'.$photo, type:'product')); ?>">
                                                                            <img class="dark-support rounded" alt=""
                                                                                src="<?php echo e(getValidImage(path: 'storage/app/public/product/'.$photo, type:'product')); ?>">
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                            <div class="mt-2 user-select-none">
                                                <div class="quickviewSliderThumb2 swiper-container position-relative ">
                                                    <?php if($product->images!=null && json_decode($product->images)>0): ?>
                                                        <div
                                                            class="swiper-wrapper auto-item-width justify-content-center border--gray width--4rem">
                                                            <?php if(json_decode($product->colors) && $product->color_image): ?>
                                                                <?php $__currentLoopData = json_decode($product->color_image); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($photo->color != null): ?>
                                                                        <div
                                                                            class="swiper-slide position-relative aspect-1">
                                                                            <img class="dark-support rounded" alt=""
                                                                                src="<?php echo e(getValidImage(path: 'storage/app/public/product/'.$photo->image_name, type:'product')); ?>">
                                                                        </div>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php $__currentLoopData = json_decode($product->color_image); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($photo->color == null): ?>
                                                                        <div class="swiper-slide position-relative aspect-1">
                                                                            <img class="dark-support rounded" alt=""
                                                                                src="<?php echo e(getValidImage(path: 'storage/app/public/product/'.$photo->image_name, type:'product')); ?>">
                                                                        </div>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php else: ?>
                                                                <?php $__currentLoopData = json_decode($product->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <div
                                                                        class="swiper-slide position-relative aspect-1">
                                                                        <img class="dark-support rounded" alt=""
                                                                            src="<?php echo e(getValidImage(path: 'storage/app/public/product/'.$photo, type:'product')); ?>">
                                                                    </div>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        </div>
                                                    <?php endif; ?>

                                                    <div
                                                        class="swiper-button-next swiper-quickview-button-next size-1-5rem"></div>
                                                    <div
                                                        class="swiper-button-prev swiper-quickview-button-prev size-1-5rem"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-7">
                                        <div class="product-details-content position-relative">
                                            <div class="d-flex flex-wrap align-items-center gap-2 mb-3">
                                                <h2 class="product_title"><?php echo e($product->name); ?></h2>
                                                <?php if($product->discount > 0 && $product->discount_type === "percent"): ?>
                                                    <span
                                                        class="product__save-amount"><?php echo e(translate('save')); ?> <?php echo e($product->discount.'%'); ?></span>
                                                <?php elseif($product->discount > 0): ?>
                                                    <span
                                                        class="product__save-amount"><?php echo e(translate('save')); ?> <?php echo e(Helpers::currency_converter($product->discount)); ?></span>
                                                <?php endif; ?>
                                            </div>

                                            <div class="d-flex gap-2 align-items-center mb-2">
                                                <div class="star-rating text-gold fs-12">
                                                    <?php for($index = 1; $index <= 5; $index++): ?>
                                                        <?php if($index <= (int)$overallRating[0]): ?>
                                                            <i class="bi bi-star-fill"></i>
                                                        <?php elseif($overallRating[0] != 0 && $index <= (int)$overallRating[0] + 1.1 && $overallRating[0] > ((int)$overallRating[0])): ?>
                                                            <i class="bi bi-star-half"></i>
                                                        <?php else: ?>
                                                            <i class="bi bi-star"></i>
                                                        <?php endif; ?>
                                                    <?php endfor; ?>
                                                </div>
                                                <span>(<?php echo e($product->reviews_count); ?>)</span>
                                            </div>
                                            <?php if(($product['product_type'] == 'physical') && ($product['current_stock']<=0)): ?>
                                                <p class="fw-semibold text-muted"><?php echo e(translate('out_of_stock')); ?></p>
                                            <?php else: ?>
                                                <?php if($product['product_type'] === 'physical'): ?>
                                                    <p class="fw-semibold text-muted">
                                                        <span class="in_stock_status"><?php echo e($product->current_stock); ?></span>
                                                        <?php echo e(translate('in_Stock')); ?>

                                                    </p>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <div class="product__price d-flex flex-wrap align-items-end gap-2 mb-4 ">
                                                <div class="text-primary fs-1-5rem"><?php echo Helpers::get_price_range_with_discount($product); ?></div>
                                            </div>
                                            <form class="cart add-to-cart-form" action="<?php echo e(route('cart.add')); ?>"
                                                  id="add-to-cart-form" data-redirecturl="<?php echo e(route('checkout-details')); ?>"
                                                  data-varianturl="<?php echo e(route('cart.variant_price')); ?>"
                                                  data-errormessage="<?php echo e(translate('please_choose_all_the_options')); ?>"
                                                  data-outofstock="<?php echo e(translate('Sorry_Out_of_stock')); ?>.">
                                                <?php echo csrf_field(); ?>
                                                <div class="">
                                                    <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                                    <?php if(count(json_decode($product->colors)) > 0): ?>
                                                        <div class="d-flex gap-4 flex-wrap align-items-center mb-3">
                                                            <h6 class="fw-semibold"><?php echo e(translate('color')); ?></h6>
                                                            <ul class="option-select-btn custom_01_option flex-wrap weight-style--two gap-2 pt-2">
                                                                <?php $__currentLoopData = json_decode($product->colors); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <li>
                                                                        <label>
                                                                            <input type="radio" hidden=""
                                                                                   id="<?php echo e($product->id); ?>-color-<?php echo e(str_replace('#','',$color)); ?>"
                                                                                   name="color" value="<?php echo e($color); ?>"
                                                                                <?php echo e($key == 0 ? 'checked' : ''); ?>

                                                                            >
                                                                            <span
                                                                                class="color_variants rounded-circle focus-preview-image-by-color p-0 <?php echo e($key == 0 ? 'color_variant_active':''); ?>"
                                                                                style="background: <?php echo e($color); ?>;"
                                                                                data-slide-id="preview-box-<?php echo e(str_replace('#','',$color)); ?>"
                                                                                id="color_variants_preview-box-<?php echo e(str_replace('#','',$color)); ?>"
                                                                            ></span>
                                                                        </label>
                                                                    </li>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </ul>
                                                        </div>
                                                    <?php endif; ?>
                                                    <?php $__currentLoopData = json_decode($product->choice_options); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="d-flex gap-4 flex-wrap align-items-center mb-4">
                                                            <h6 class="fw-semibold"><?php echo e(translate($choice->title)); ?></h6>
                                                            <ul class="option-select-btn custom_01_option flex-wrap weight-style--two gap-2">
                                                                <?php $__currentLoopData = $choice->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <li>
                                                                        <label>
                                                                            <input type="radio" hidden=""
                                                                                   id="<?php echo e($choice->name); ?>-<?php echo e($option); ?>"
                                                                                   name="<?php echo e($choice->name); ?>"
                                                                                   value="<?php echo e($option); ?>"
                                                                                   <?php if($key == 0): ?> checked <?php endif; ?> >
                                                                            <span><?php echo e($option); ?></span>
                                                                        </label>
                                                                    </li>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </ul>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="d-flex gap-4 flex-wrap align-items-center mb-4">
                                                        <h6 class="fw-semibold"><?php echo e(translate('quantity')); ?></h6>
                                                        <div class="quantity quantity--style-two">
                                                            <span class="quantity__minus single-quantity-minus">
                                                                <i class="bi bi-trash3-fill text-danger fs-10"></i>
                                                            </span>
                                                            <input type="text"
                                                                   class="quantity__qty product_quantity__qty"
                                                                   name="quantity"
                                                                   value="<?php echo e($product?->minimum_order_qty ?? 1); ?>"
                                                                   min="<?php echo e($product?->minimum_order_qty ?? 1); ?>"
                                                                   max="<?php echo e($product['product_type'] == 'physical' ? $product->current_stock : 100); ?>">
                                                            <span class="quantity__plus single-quantity-plus" <?php echo e(($product->current_stock == 1?'disabled':'')); ?>>
                                                                <i class="bi bi-plus"></i>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <div class="mx-w width--24rem">
                                                        <div class="bg-light w-100 rounded p-4">
                                                            <div class="flex-between-gap-3">
                                                                <div class="">
                                                                    <h6 class="flex-middle-gap-2 mb-2">
                                                                        <span
                                                                            class="text-muted"><?php echo e(translate('total_price').':'); ?></span>
                                                                        <span
                                                                            class="total_price"><?php echo e(Helpers::currency_converter($product->unit_price)); ?></span>
                                                                    </h6>
                                                                    <h6 class="flex-middle-gap-2">
                                                                        <span
                                                                            class="text-muted"><?php echo e(translate('tax').':'); ?></span>
                                                                        <span
                                                                            class="product_vat"><?php echo e($product->tax_model == 'include' ? 'incl.' : Helpers::currency_converter($product->tax)); ?></span>
                                                                    </h6>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="mx-w d-flex flex-wrap gap-3 mt-4 width--24rem">
                                                        <?php if(($product->added_by == 'seller' && ($sellerTemporaryClose || (isset($product->seller->shop) && $product->seller->shop->vacation_status && $currentDate >= $sellerVacationStartDate && $currentDate <= $sellerVacationEndDate))) ||
                                                        ($product->added_by == 'admin' && ($inHouseTemporaryClose || ($inHouseVacationStatus && $currentDate >= $inHouseVacationStartDate && $currentDate <= $inHouseVacationEndDate)))): ?>
                                                            <button type="button"
                                                                    class="btn btn-secondary fs-16 flex-grow-1"
                                                                    disabled><?php echo e(translate('buy_now')); ?></span></button>
                                                            <button type="button"
                                                                    class="btn btn-primary fs-16 flex-grow-1 text-capitalize"
                                                                    disabled><?php echo e(translate('add_to_cart')); ?></button>
                                                        <?php else: ?>
                                                            <?php ($guest_checkout=getWebConfig(name: 'guest_checkout')); ?>
                                                            <button type="button"
                                                                    class="btn btn-secondary fs-16 buy-now"
                                                                    data-form-id="add-to-cart-form"
                                                                    data-redirect-status="<?php echo e(($guest_checkout==1 || Auth::guard('customer')->check()?'true':'false')); ?>"
                                                                    data-action="<?php echo e(route('shop-cart')); ?>"><?php echo e(translate('buy_now')); ?></span>
                                                            </button>
                                                            <button type="button" class="btn btn-primary fs-16 text-capitalize add-to-cart"
                                                                    data-form-id="add-to-cart-form"><?php echo e(translate('add_to_cart')); ?></button>
                                                        <?php endif; ?>
                                                    </div>
                                                    <?php if(($product->added_by == 'seller' && ($sellerTemporaryClose || (isset($product->seller->shop) && $product->seller->shop->vacation_status && $currentDate >= $sellerVacationStartDate && $currentDate <= $sellerVacationEndDate))) ||
                                                    ($product->added_by == 'admin' && ($sellerTemporaryClose || ($inHouseVacationStatus && $currentDate >= $inHouseVacationStartDate && $currentDate <= $inHouseVacationEndDate)))): ?>
                                                        <div class="alert alert-danger mt-3" role="alert">
                                                            <?php echo e(translate('this_shop_is_temporary_closed_or_on_vacation').'.'.translate('you_cannot_add_product_to_cart_from_this_shop_for_now')); ?>

                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <nav>
                                <div class="nav justify-content-center gap-4 nav--tabs" id="nav-tab" role="tablist">
                                    <button class="active text-capitalize" id="product-details-tab" data-bs-toggle="tab"
                                            data-bs-target="#product-details" type="button" role="tab"
                                            aria-controls="product-details"
                                            aria-selected="true"><?php echo e(translate('product_details')); ?></button>
                                    <button id="reviews-tab" data-bs-toggle="tab" data-bs-target="#reviews"
                                            type="button" role="tab" aria-controls="reviews"
                                            aria-selected="false"><?php echo e(translate("reviews")); ?></button>
                                </div>
                            </nav>
                            <div class="tab-content mt-3" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="product-details" role="tabpanel"
                                     aria-labelledby="product-details-tab" tabindex="0">
                                    <div class="details-content-wrap custom-height ov-hidden show-more--content active">
                                        <div class="table-responsive">
                                            <table class="table mb-0">
                                                <thead class="table-light">
                                                <tr>
                                                    <th class="border-0 text-capitalize"><?php echo e(translate('details_description')); ?></th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr>
                                                    <td>
                                                        <?php if($product->video_url != null && (str_contains($product->video_url, "youtube.com/embed/"))): ?>
                                                            <div class="col-12 mb-4 text-center">
                                                                <iframe width="560" height="315"
                                                                        src="<?php echo e($product->video_url); ?>">
                                                                </iframe>
                                                            </div>
                                                        <?php endif; ?>
                                                        <?php echo $product->details; ?>

                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="d-flex justify-content-center mt-2">
                                        <button class="btn btn-outline-primary see-more-details"><?php echo e(translate('see_more')); ?></button>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="reviews" role="tabpanel" aria-labelledby="reviews-tab"
                                     tabindex="0">
                                    <div class="details-content-wrap custom-height ov-hidden show-more--content active">
                                        <div class="row gy-4">
                                            <div class="col-lg-5">
                                                <div class="rating-review mx-auto text-center mb-30">
                                                    <h2 class="rating-review__title"><span
                                                            class="rating-review__out-of"><?php echo e(round($overallRating[0], 1)); ?></span>/5
                                                    </h2>
                                                    <div class="rating text-gold mb-2">
                                                        <?php for($increment = 1; $increment <= 5; $increment++): ?>
                                                            <?php if($increment <= (int)$overallRating[0]): ?>
                                                                <i class="bi bi-star-fill"></i>
                                                            <?php elseif($overallRating[0] != 0 && $increment <= (int)$overallRating[0] + 1.1 && $overallRating[0] > ((int)$overallRating[0])): ?>
                                                                <i class="bi bi-star-half"></i>
                                                            <?php else: ?>
                                                                <i class="bi bi-star"></i>
                                                            <?php endif; ?>
                                                        <?php endfor; ?>
                                                    </div>
                                                    <div class="rating-review__info">
                                                        <span><?php echo e($productReviews->total().' '.translate($productReviews->total() <=1 ? 'review' : 'reviews')); ?></span>
                                                    </div>
                                                </div>
                                                <ul class="list-rating gap-10">
                                                    <li>
                                                        <span class="review-name">5 <?php echo e(translate('star')); ?></span>

                                                        <div class="progress">
                                                            <div class="progress-bar" role="progressbar"
                                                                 style="width: <?php echo e(($rating[0] != 0?number_format($rating[0]*100 / array_sum($rating)):0)); ?>%"
                                                                 aria-valuenow="95" aria-valuemin="0"
                                                                 aria-valuemax="100">
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <span class="review-name">4 <?php echo e(translate('star')); ?></span>

                                                        <div class="progress">
                                                            <div class="progress-bar" role="progressbar"
                                                                 style="width: <?php echo e(($rating[1] != 0?number_format($rating[1]*100 / array_sum($rating)):0)); ?>%"
                                                                 aria-valuenow="35" aria-valuemin="0"
                                                                 aria-valuemax="100">
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <span class="review-name">3 <?php echo e(translate('star')); ?></span>

                                                        <div class="progress">
                                                            <div class="progress-bar" role="progressbar"
                                                                 style="width: <?php echo e(($rating[2] != 0?number_format($rating[2]*100 / array_sum($rating)):0)); ?>%"
                                                                 aria-valuenow="35" aria-valuemin="0"
                                                                 aria-valuemax="100">
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <span class="review-name">2 <?php echo e(translate('star')); ?></span>

                                                        <div class="progress">
                                                            <div class="progress-bar" role="progressbar"
                                                                 style="width: <?php echo e(($rating[3] != 0?number_format($rating[3]*100 / array_sum($rating)):0)); ?>%"
                                                                 aria-valuenow="20" aria-valuemin="0"
                                                                 aria-valuemax="100">
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <span class="review-name">1 <?php echo e(translate('star')); ?></span>

                                                        <div class="progress">
                                                            <div class="progress-bar" role="progressbar"
                                                                 style="width: <?php echo e(($rating[4] != 0?number_format($rating[4]*100 / array_sum($rating)):0)); ?>%"
                                                                 aria-valuenow="10" aria-valuemin="0"
                                                                 aria-valuemax="100">
                                                            </div>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="col-lg-7">
                                                <div class="d-flex flex-wrap gap-3" id="product-review-list">
                                                    <?php $__currentLoopData = $productReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="card border-primary-light flex-grow-1">
                                                            <div class="media flex-wrap align-items-centr gap-3 p-3">
                                                                <div
                                                                    class="avatar overflow-hidden border rounded-circle size-3-437rem">
                                                                    <img alt="" class="img-fit dark-support"
                                                                        src="<?php echo e(getValidImage(path: 'storage/app/public/profile/'.(isset($review->user)?$review->user->image : ''), type: 'avatar')); ?>">
                                                                </div>
                                                                <div class="media-body d-flex flex-column gap-2">
                                                                    <div
                                                                        class="d-flex flex-wrap gap-2 align-items-center justify-content-between">
                                                                        <div>
                                                                            <h6 class="mb-1 text-capitalize"><?php echo e(isset($review->user)?$review->user->f_name:translate('user_not_exist')); ?></h6>
                                                                            <div
                                                                                class="d-flex gap-2 align-items-center">
                                                                                <div
                                                                                    class="star-rating text-gold fs-12">
                                                                                    <?php for($inc=0; $inc < 5; $inc++): ?>
                                                                                        <?php if($inc < $review->rating): ?>
                                                                                            <i class="bi bi-star-fill"></i>
                                                                                        <?php else: ?>
                                                                                            <i class="bi bi-star"></i>
                                                                                        <?php endif; ?>
                                                                                    <?php endfor; ?>
                                                                                </div>
                                                                                <span>(<?php echo e($review->rating); ?>/5)</span>
                                                                            </div>
                                                                        </div>
                                                                        <div><?php echo e($review->created_at->format("d M Y h:i:s A")); ?></div>
                                                                    </div>
                                                                    <p><?php echo e($review->comment); ?></p>
                                                                    <?php if(isset($review->attachment)): ?>
                                                                    <div
                                                                        class="d-flex flex-wrap gap-2 products-comments-img">
                                                                        <?php $__currentLoopData = json_decode($review->attachment); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <a href="<?php echo e(getValidImage(path: 'storage/app/public/review/'.$img, type:'product')); ?>" class="custom-image-popup mx-3">
                                                                                <img class="remove-mask-img" alt=""
                                                                                    src="<?php echo e(getValidImage(path: 'storage/app/public/review/'.$img, type:'product')); ?>">
                                                                            </a>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </div>
                                                                   <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(count($productReviews)==0): ?>
                                                        <div class="card">
                                                            <div class="card-body">
                                                                <h6 class="text-danger text-center m-0"><?php echo e(translate('product_review_not_available')); ?></h6>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="d-flex justify-content-center mt-2">
                                        <?php if($productReviews->total() > 2): ?>
                                            <button
                                                class="btn btn-outline-primary see-more-details-review m-1 view_text"
                                                id="see-more"
                                                data-product-id="<?php echo e($product->id); ?>"
                                                data-action="<?php echo e(route('review-list-product')); ?>"
                                                data-after-extend="<?php echo e(translate('see_less')); ?>"
                                                data-see-more="<?php echo e(translate('see_more')); ?>"
                                                data-onerror="<?php echo e(translate('no_more_review_remain_to_load')); ?>"><?php echo e(translate('see_more')); ?></button>
                                        <?php else: ?>
                                            <button
                                                class="btn btn-outline-primary see-more-details m-1"><?php echo e(translate('see_more')); ?></button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-xl-3 d-flex flex-column gap-3">
                    <?php if(count($moreProductFromSeller)>0): ?>
                    <div class="card order-1 order-sm-0">
                        <div class="card-body">
                            <h5 class="mb-3 text-capitalize"><?php echo e(translate('more_from_the_store')); ?></h5>
                            <div class="d-flex flex-wrap gap-3">
                                <?php $__currentLoopData = $moreProductFromSeller; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="card border-primary-light flex-grow-1">
                                        <a href="<?php echo e(route('product',$item->slug)); ?>"
                                           class="media align-items-centr gap-3 p-3 ">
                                            <div class="avatar size-4-375rem">
                                                <img class="img-fit dark-support rounded img-fluid overflow-hidden"
                                                    alt=""
                                                    src="<?php echo e(getValidImage(path: 'storage/app/public/product/thumbnail/'.$item['thumbnail'], type: 'product')); ?>">
                                            </div>
                                            <?php ($itemReview = getOverallRating($item->reviews)); ?>
                                            <div class="media-body d-flex flex-column gap-2">
                                                <h6 class="text-capitalize"><?php echo e(Str::limit($item['name'], 18)); ?></h6>
                                                <div class="d-flex gap-2 align-items-center">
                                                    <div class="star-rating text-gold fs-12">
                                                        <?php for($index = 1; $index <= 5; $index++): ?>
                                                            <?php if($index <= (int)$itemReview[0]): ?>
                                                                <i class="bi bi-star-fill"></i>
                                                            <?php elseif($itemReview[0] != 0 && $index <= (int)$itemReview[0] + 1.1 && $itemReview[0] > ((int)$itemReview[0])): ?>
                                                                <i class="bi bi-star-half"></i>
                                                            <?php else: ?>
                                                                <i class="bi bi-star"></i>
                                                            <?php endif; ?>
                                                        <?php endfor; ?>
                                                    </div>
                                                    <span>(<?php echo e($item->reviews_count); ?>)</span>
                                                </div>
                                                <div class="product__price">
                                                    <ins class="product__new-price">
                                                        <?php echo e(Helpers::currency_converter($item->unit_price-(Helpers::get_product_discount($item,$item->unit_price)))); ?>

                                                    </ins>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if($product->added_by=='seller'): ?>
                        <?php if(isset($product->seller->shop)): ?>
                            <div class="card order-0 order-sm-1">
                                <div class="card-body">
                                    <div class="p-2 overlay shop-bg-card"
                                         data-bg-img="<?php echo e(getValidImage(path: 'storage/app/public/shop/banner/'.($product->seller->shop->banner), type: 'shop-banner')); ?>">
                                        <div class="media flex-wrap gap-3 p-2">
                                            <div class="avatar border rounded-circle size-3-437rem get-view-by-onclick cursor-pointer" data-link="<?php echo e(route('shopView',[$product->seller->id])); ?>">
                                                <img alt="" class="img-fit dark-support rounded-circle"
                                                    src="<?php echo e(getValidImage(path: 'storage/app/public/shop/'.($product->seller->shop->image), type:'shop')); ?>">
                                            </div>
                                            <div class="media-body d-flex flex-column gap-2 text-absolute-whtie get-view-by-onclick" data-link="<?php echo e(route('shopView',[$product->seller->id])); ?>">
                                                <div class="d-flex flex-column gap-1 justify-content-start">
                                                    <h5 class="cursor-pointer"><?php echo e($product->seller->shop->name); ?></h5>
                                                    <div class="d-flex gap-2 align-items-center ">
                                                        <div class="star-rating text-gold fs-12">
                                                            <?php for($increment = 1; $increment <= 5; $increment++): ?>
                                                                <?php if($increment <= (int)$avgRating): ?>
                                                                    <i class="bi bi-star-fill"></i>
                                                                <?php elseif($avgRating != 0 && $increment <= (int)$avgRating + 1.1 && $avgRating > ((int)$avgRating)): ?>
                                                                    <i class="bi bi-star-half"></i>
                                                                <?php else: ?>
                                                                    <i class="bi bi-star"></i>
                                                                <?php endif; ?>
                                                            <?php endfor; ?>
                                                        </div>
                                                        <span>(<?php echo e($totalReviews); ?>)</span>
                                                    </div>
                                                    <h6 class="fw-semibold"><?php echo e($productsForReview->count()); ?> <?php echo e(translate('products')); ?></h6>
                                                </div>

                                                <div class="mb-3">
                                                    <div class="text-center d-inline-block">
                                                        <h3 class="mb-1"><?php echo e(round($ratingPercentage).'%'); ?></h3>
                                                        <div class="fs-12"><?php echo e(translate('positive_review')); ?></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php if(auth('customer')->id() == ''): ?>
                                                <div class="btn-circle chat-btn size-2-5rem"
                                                     data-bs-toggle="modal" data-bs-target="#loginModal">
                                                    <i class="bi bi-chat-square-dots"></i>
                                                </div>
                                            <?php else: ?>
                                                <div class="btn-circle chat-btn size-2-5rem"
                                                     data-bs-toggle="modal" data-bs-target="#contact_sellerModal">
                                                    <i class="bi bi-chat-square-dots"></i>
                                                </div>
                                            <?php endif; ?>
                                        </div>

                                        <a href="<?php echo e(route('shopView',[$product->seller->id])); ?>"
                                           class="btn btn-primary btn-block text-capitalize"><?php echo e(translate('visit_store')); ?></a>
                                    </div>
                                </div>
                            </div>
                            <?php echo $__env->make('theme-views.layouts.partials.modal._chat-with-seller',['seller_id'=>$product->seller->id,'shop_id'=>$product->seller->shop->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="card  order-0 order-sm-1">
                            <div class="card-body">
                                <div class="p-2 overlay shop-bg-card"
                                     data-bg-img="<?php echo e(asset('storage/app/public/shop/'.getWebConfig(name: 'shop_banner'))); ?>">
                                    <div class="media flex-wrap gap-3 p-2 get-view-by-onclick" data-link="<?php echo e(route('shopView',[0])); ?>">
                                        <div class="avatar border rounded-circle size-3-437rem cursor-pointer">
                                            <img alt="" class="img-fit dark-support rounded-circle"
                                                src="<?php echo e(getValidImage(path: 'storage/app/public/company/'.$web_config['fav_icon']->value, type:'shop')); ?>">
                                        </div>

                                        <div class="media-body d-flex flex-column gap-2 text-absolute-whtie">
                                            <div class="d-flex flex-column gap-1 justify-content-start">
                                                <h5 class="cursor-pointer get-view-by-onclick" data-link="<?php echo e(route('shopView',[0])); ?>"><?php echo e($web_config['name']->value); ?></h5>
                                                <div class="d-flex gap-2 align-items-center ">
                                                    <div class="star-rating text-gold fs-12">
                                                        <?php for($index = 1; $index <= 5; $index++): ?>
                                                            <?php if($index <= (int)$avgRating): ?>
                                                                <i class="bi bi-star-fill"></i>
                                                            <?php elseif($avgRating != 0 && $index <= (int)$avgRating + 1.1 && $avgRating > ((int)$avgRating)): ?>
                                                                <i class="bi bi-star-half"></i>
                                                            <?php else: ?>
                                                                <i class="bi bi-star"></i>
                                                            <?php endif; ?>
                                                        <?php endfor; ?>
                                                    </div>

                                                    <span>(<?php echo e($totalReviews); ?>)</span>
                                                </div>
                                                <h6 class="fw-semibold"><?php echo e($productsForReview->count()); ?> <?php echo e(translate('Products')); ?></h6>

                                                <div class="mb-3">
                                                    <div class="text-center d-inline-block">
                                                        <h3 class="mb-1"><?php echo e(round($ratingPercentage).'%'); ?></h3>
                                                        <div class="fs-12"><?php echo e(translate('positive_review')); ?></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <a href="<?php echo e(route('shopView',[0])); ?>"
                                       class="btn btn-primary btn-block text-capitalize"><?php echo e(translate('visit_store')); ?></a>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php if(count($relatedProducts)>0): ?>
                <div class="py-4 mt-3">
                    <div class="d-flex justify-content-between gap-3 mb-4">
                        <h2 class="text-capitalize"><?php echo e(translate('similar_products_from_other_stores')); ?></h2>
                        <div class="swiper-nav d-flex gap-2 align-items-center">
                            <div class="swiper-button-prev top-rated-nav-prev position-static rounded-10"></div>
                            <div class="swiper-button-next top-rated-nav-next position-static rounded-10"></div>
                        </div>
                    </div>
                    <div class="swiper-container">
                        <div class="position-relative">
                            <div class="swiper" data-swiper-loop="false" data-swiper-margin="20" data-swiper-autoplay="true"
                                 data-swiper-pagination-el="null" data-swiper-navigation-next=".top-rated-nav-next"
                                 data-swiper-navigation-prev=".top-rated-nav-prev"
                                 data-swiper-breakpoints='{"0": {"slidesPerView": "1"}, "320": {"slidesPerView": "2"}, "992": {"slidesPerView": "3"}, "1200": {"slidesPerView": "4"}, "1400": {"slidesPerView": "5"}}'>
                                <div class="swiper-wrapper">
                                    <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$relatedProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="swiper-slide">
                                            <?php echo $__env->make('theme-views.partials._similar-product-large-card',['product'=>$relatedProduct], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(theme_asset('assets/plugins/easyzoom/easyzoom.min.js')); ?>"></script>
    <script>
        'use strict';
        $(".easyzoom").each(function () {
            $(this).easyZoom();
        });
        getVariantPrice();
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('theme-views.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/blunxtld/public_html/resources/themes/theme_aster/theme-views/product/details.blade.php ENDPATH**/ ?>