<?php $__env->startSection('title', translate('FAQ')); ?>
<?php $__env->startPush('css_or_js'); ?>
    <meta property="og:image" content="<?php echo e(asset('storage/app/public/company')); ?>/<?php echo e($web_config['web_logo']->value); ?>"/>
    <meta property="og:title" content="FAQ of <?php echo e($web_config['name']->value); ?> "/>
    <meta property="og:url" content="<?php echo e(env('APP_URL')); ?>">
    <meta property="og:description" content="<?php echo substr($web_config['about']->value,0,100); ?>">
    <meta property="twitter:card" content="<?php echo e(asset('storage/app/public/company')); ?>/<?php echo e($web_config['web_logo']->value); ?>"/>
    <meta property="twitter:title" content="FAQ of <?php echo e($web_config['name']->value); ?>"/>
    <meta property="twitter:url" content="<?php echo e(env('APP_URL')); ?>">
    <meta property="twitter:description" content="<?php echo substr($web_config['about']->value,0,100); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <main class="main-content d-flex flex-column gap-3 pt-3 mb-sm-5">
        <div class="page-title overlay py-5 __opacity-half background-custom-fit"
             <?php if($pageTitleBanner): ?>
                 <?php if(File::exists(base_path('storage/app/public/banner/'.json_decode($pageTitleBanner['value'])->image))): ?>
                     data-bg-img="<?php echo e(asset('storage/app/public/banner/'.json_decode($pageTitleBanner['value'])->image)); ?>"
                 <?php else: ?>
                     data-bg-img="<?php echo e(theme_asset('assets/img/media/page-title-bg.png')); ?>"
                 <?php endif; ?>
             <?php else: ?>
                 data-bg-img="<?php echo e(theme_asset('assets/img/media/page-title-bg.png')); ?>"
            <?php endif; ?>
        >
            <div class="container">
                <h1 class="absolute-white text-center"><?php echo e(translate('FAQ')); ?></h1>
            </div>
        </div>
        <?php
            $length=count($helps);
                if($length%2!=0){
                    $first=($length+1)/2;
                }else{
                    $first=$length/2;
                }
        ?>
        <div class="container">
            <div class="my-4">
                <div class="accordion accordion-flush" id="accordionFlushExample">
                    <?php ($index = 0); ?>
                    <?php $__currentLoopData = $helps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $help): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="flush-heading<?php echo e($help['id']); ?>">
                                <button class="accordion-button text-dark fw-semibold" type="button"
                                        data-bs-toggle="collapse" data-bs-target="#flush-collapse<?php echo e($help['id']); ?>"
                                        aria-expanded="false" aria-controls="flush-collapse<?php echo e($help['id']); ?>">
                                    <?php echo e($help['question']); ?>

                                </button>
                            </h2>
                            <div id="flush-collapse<?php echo e($help['id']); ?>"
                                 class="accordion-collapse collapse <?php echo e($index == 0 ? 'show' : ''); ?>"
                                 aria-labelledby="flush-heading<?php echo e($help['id']); ?>"
                                 data-bs-parent="#accordionFlushExample">
                                <div class="accordion-body">
                                    <?php echo e($help['answer']); ?>

                                </div>
                            </div>
                        </div>
                        <?php ($index++); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('theme-views.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/blunxtld/public_html/resources/themes/theme_aster/theme-views/pages/help-topics.blade.php ENDPATH**/ ?>