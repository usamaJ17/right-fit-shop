<?php $__env->startSection('title', translate('all_Brands_Page').' | '.$web_config['name']->value.' '.translate('ecommerce')); ?>

<?php $__env->startSection('content'); ?>
    <main class="main-content d-flex flex-column gap-3 py-3 mb-30">
        <div class="container">
            <div class="card mb-3">
                <div class="card-body">
                    <div class="row gy-2 align-items-center">
                        <div class="col-md-6">
                            <h3 class="mb-1 text-capitalize"><?php echo e(translate('all_brands')); ?></h3>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb fs-12 mb-0">
                                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><?php echo e(translate('home')); ?></a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><?php echo e(translate('brands')); ?></li>
                                </ol>
                            </nav>
                        </div>
                        <div class="col-md-6">
                            <div class="d-flex justify-content-md-end">
                                <div class="border rounded custom-ps-3 py-2">
                                    <div class="d-flex gap-2">
                                        <div class="flex-middle gap-2">
                                            <i class="bi bi-sort-up-alt"></i>
                                            <?php echo e(translate('show_brand :')); ?>

                                        </div>
                                        <div class="dropdown">
                                            <button type="button" class="border-0 bg-transparent dropdown-toggle p-0 custom-pe-3" data-bs-toggle="dropdown" aria-expanded="false">
                                                <?php if(isset($order_by) && $order_by=='desc'): ?>
                                                    <?php echo e(translate('Z-A')); ?>

                                                <?php elseif(isset($order_by) && $order_by=='asc'): ?>
                                                    <?php echo e(translate('A-Z')); ?>

                                                <?php else: ?>
                                                    <?php echo e(translate('new_arrival')); ?>

                                                <?php endif; ?>
                                            </button>
                                            <ul class="dropdown-menu dropdown-menu-end">
                                                <li>
                                                    <a class="d-flex" href="<?php echo e(route('brands')); ?>">
                                                        <?php echo e(translate('new_arrival')); ?>

                                                    </a>
                                                </li>
                                                <li>
                                                    <a class="d-flex" href="<?php echo e(route('brands')); ?>/?order_by=asc">
                                                        <?php echo e(translate('A-Z')); ?>

                                                    </a>
                                                </li>
                                                <li>
                                                    <a class="d-flex" href="<?php echo e(route('brands')); ?>/?order_by=desc">
                                                        <?php echo e(translate('Z-A')); ?>

                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="auto-col xxl-items-6 justify-content-center gap-3">
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="brand-item grid-center">
                            <div class="hover__action">
                                <a href="<?php echo e(route('products',['id'=> $brand['id'],'data_from'=>'brand','page'=>1])); ?>" class="eye-btn mx-auto mb-3">
                                    <i class="bi bi-eye fs-12"></i>
                                </a>
                                <div class="d-flex flex-column flex-wrap gap-1 text-white">
                                    <h6 class="text-white"><?php echo e($brand->brand_products_count); ?></h6>
                                    <p><?php echo e(translate('Products')); ?></p>
                                </div>
                            </div>
                            <img width="130" loading="lazy" class="dark-support rounded text-center"
                                 src="<?php echo e(getValidImage(path: 'storage/app/public/brand/'.$brand->image, type:'brand')); ?>" alt="<?php echo e($brand->name); ?>">
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($brands->count()==0): ?>
                                <div class="mb-2 mt-3"><h5 class="text-center"><?php echo e(translate('not_found_anything')); ?></h5></div>
                            <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="card-footer border-0">
            <?php echo e($brands->links()); ?>

        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme-views.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/blunxtld/public_html/resources/themes/theme_aster/theme-views/product/brands.blade.php ENDPATH**/ ?>