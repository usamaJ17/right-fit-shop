<?php
    use App\Utils\Helpers;
    use App\Utils\ProductManager;
?>
<section>
    <div class="container">
        <div class="card">
            <div class="p-3 p-sm-4">
                <div class="d-flex flex-wrap justify-content-between gap-3 mb-3 mb-sm-4">
                    <div class="d-flex flex-wrap gap-3 align-items-center">
                        <h2><span class="text-primary"><?php echo e(translate('top')); ?></span> <?php echo e(translate('stores')); ?></h2>
                    </div>
                    <div class="swiper-nav d-flex gap-2 align-items-center">
                        <a href="<?php echo e(route('vendors')); ?>" class="btn-link text-primary text-capitalize"><?php echo e(translate('view_all')); ?></a>
                        <div class="swiper-button-prev top-stores-nav-prev position-static rounded-10"></div>
                        <div class="swiper-button-next top-stores-nav-next position-static rounded-10"></div>
                    </div>
                </div>
                <div class="swiper-container">
                    <div class="position-relative">
                        <div class="swiper" data-swiper-loop="true" data-swiper-margin="20"
                             data-swiper-pagination-el="null" data-swiper-navigation-next=".top-stores-nav-next"
                             data-swiper-navigation-prev=".top-stores-nav-prev"
                             data-swiper-breakpoints='{"0": {"slidesPerView": "1"}, "768": {"slidesPerView": "2"}, "992": {"slidesPerView": "3"}}'>
                            <div class="swiper-wrapper">
                                <?php $__currentLoopData = $top_sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($seller->shop): ?>
                                        <div class="swiper-slide align-items-start bg-light rounded">
                                            <div class="bg-light position-relative rounded p-3 p-sm-4 w-100">
                                                <?php if(count($seller->coupon)>0): ?>
                                                    <div class="offer-text">
                                                        <?php echo e(translate('USE_COUPON').':'); ?>

                                                        <span class="cursor-pointer coupon-copy"
                                                              data-copy-coupun="<?php echo e($seller->coupon[0]['code']); ?>">
                                                            <?php echo e($seller->coupon[0]['code']); ?>

                                                         </span>
                                                    </div>
                                                <?php endif; ?>
                                                <div class="<?php echo e(count($seller->coupon)>0 ? 'mt-4' :''); ?> mb-3">
                                                    <h5 class="mb-1"><a href="<?php echo e(route('shopView',['id'=>$seller['id']])); ?>"><?php echo e($seller->shop->name); ?></a>
                                                    </h5>
                                                    <div
                                                        class="text-muted"><?php echo e($seller->product_count); ?> <?php echo e(translate('products')); ?></div>
                                                    <div class="d-flex gap-2 align-items-center mt-1">
                                                        <div class="star-rating text-gold fs-12">
                                                            <?php for($inc=0;$inc<5;$inc++): ?>
                                                                <?php if($inc<$seller->average_rating): ?>
                                                                    <i class="bi bi-star-fill"></i>
                                                                <?php else: ?>
                                                                    <i class="bi bi-star"></i>
                                                                <?php endif; ?>
                                                            <?php endfor; ?>
                                                        </div>
                                                        <span>(<?php echo e($seller->rating_count); ?>)</span>
                                                    </div>
                                                </div>
                                                <?php if($seller->product): ?>
                                                    <div class="auto-col gap-3 minWidth-3-75rem"
                                                         style="--maxWidth: <?php echo e(count($seller->product)==1 ? '6.5rem' : '1fr'); ?>">
                                                        <?php $__currentLoopData = $seller->product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <a href="<?php echo e(route('product',$product['slug'])); ?>"
                                                               class="store-product d-flex flex-column gap-2 align-items-center">
                                                                <div class="store-product__top border rounded">
                                                                    <span class="store-product__action preventDefault get-quick-view"
                                                                            data-product-id = "<?php echo e($product['id']); ?>"
                                                                            data-action = "<?php echo e(route('quick-view')); ?>"
                                                                            >
                                                                        <i class="bi bi-eye fs-12"></i>
                                                                    </span>
                                                                    <img width="100"
                                                                         src="<?php echo e(getValidImage(path: 'storage/app/public/product/thumbnail/'.$product['thumbnail'], type: 'product')); ?>"
                                                                         alt="" loading="lazy"
                                                                         class="dark-support rounded">
                                                                </div>
                                                                <div
                                                                    class="product__price d-flex justify-content-center flex-wrap column-gap-2">
                                                                    <?php if($product['discount'] > 0): ?>
                                                                        <del
                                                                            class="product__old-price"><?php echo e(Helpers::currency_converter($product['unit_price'])); ?></del>
                                                                    <?php endif; ?>
                                                                    <ins class="product__new-price">
                                                                        <?php echo e(Helpers::currency_converter($product['unit_price']-Helpers::get_product_discount($product,$product['unit_price']))); ?>

                                                                    </ins>
                                                                </div>
                                                            </a>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php if(isset($footer_banner[1])): ?>
            <div class="col-12 mt-3 d-sm-none">
                <a href="<?php echo e($footer_banner[1]['url']); ?>" class="ad-hover">
                    <img src="<?php echo e(getValidImage(path: 'storage/app/public/banner/'.$footer_banner[1]['photo'], type:'banner')); ?>" loading="lazy"
                         class="dark-support rounded w-100" alt="">
                </a>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php /**PATH /home/blunxtld/public_html/resources/themes/theme_aster/theme-views/partials/_top-stores.blade.php ENDPATH**/ ?>