<div class="modal fade" id="contact_sellerModal" tabindex="-1" aria-labelledby="contact_sellerModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header px-sm-5 pb-1">
                <h5 class="text-capitalize" id="contact_sellerModalLabel"><?php echo e(translate('contact_with_vendor')); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body px-sm-5">
                <form action="<?php echo e(route('messages_store')); ?>" method="post" id="contact_with_seller_form" data-success-message="<?php echo e(translate('send_successfully')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php if($shop_id != 0): ?>
                        <input value="<?php echo e($shop_id); ?>" name="shop_id" hidden>
                        <input value="<?php echo e($seller_id); ?>" name="seller_id" hidden>
                    <?php endif; ?>

                    <textarea name="message" class="form-control" row="8" required placeholder="<?php echo e(translate('type_your_message')); ?>"></textarea>
                    <div class="d-flex justify-content-between mt-3">
                        <div class="d-flex">
                            <button class="btn btn-primary me-2" <?php echo e(($shop_id == 0?'disabled':'')); ?>><?php echo e(translate('send')); ?></button>
                            <button type="button" class="btn btn-secondary me-2" data-bs-dismiss="modal"><?php echo e(translate('close')); ?></button>
                        </div>
                        <div>
                            <?php if($shop_id != 0): ?>
                            <a href="<?php echo e(route('chat', ['type' => 'seller'])); ?>" class="btn btn-primary me-2 text-capitalize <?php echo e(($shop_id == 0?'d-none':'')); ?>"><?php echo e(translate('go_to_chatbox')); ?></a>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/blunxtld/public_html/resources/themes/theme_aster/theme-views/layouts/partials/modal/_chat-with-seller.blade.php ENDPATH**/ ?>