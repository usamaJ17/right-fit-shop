<?php $__env->startSection('title', translate('coupon_Edit')); ?>

<?php $__env->startSection('content'); ?>
<div class="content container-fluid">
    <div class="mb-3">
        <h2 class="h1 mb-0 text-capitalize">
            <img src="<?php echo e(asset('/public/assets/back-end/img/coupon_setup.png')); ?>" class="mb-1 mr-1" alt="">
            <?php echo e(translate('coupon_update')); ?>

        </h2>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">

                <div class="card-body">
                    <form action="<?php echo e(route('admin.coupon.update',[$coupon['id']])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6 col-lg-4 form-group">
                                <label for="name" class="title-color text-capitalize"><?php echo e(translate('coupon_type')); ?></label>
                                <select class="form-control" id="coupon_type" name="coupon_type" required>
                                    <option disabled selected><?php echo e(translate('select_Coupon_Type')); ?></option>
                                    <option value="discount_on_purchase" <?php echo e($coupon['coupon_type']=='discount_on_purchase'?'selected':''); ?>><?php echo e(translate('discount_on_Purchase')); ?></option>
                                    <option value="free_delivery" <?php echo e($coupon['coupon_type']=='free_delivery'?'selected':''); ?>><?php echo e(translate('free_Delivery')); ?></option>
                                    <option value="first_order" <?php echo e($coupon['coupon_type']=='first_order'?'selected':''); ?>><?php echo e(translate('first_Order')); ?></option>
                                </select>
                            </div>
                            <div class="col-md-6 col-lg-4 form-group">
                                <label for="name" class="title-color text-capitalize"><?php echo e(translate('coupon_title')); ?></label>
                                <input type="text" name="title" class="form-control" id="title" value="<?php echo e($coupon['title']); ?>"
                                       placeholder="<?php echo e(translate('title')); ?>" required>
                            </div>
                            <div class="col-md-6 col-lg-4 form-group">
                                <label for="name" class="title-color text-capitalize"><?php echo e(translate('coupon_code')); ?></label>
                                <a href="javascript:void(0)" class="float-right" id="generateCode"><?php echo e(translate('generate_code')); ?></a>
                                <input type="text" name="code" value="<?php echo e($coupon['code']); ?>"
                                       class="form-control" id="code"
                                       placeholder="<?php echo e(translate('ex')); ?>: EID100" required>
                            </div>
                            <div class="col-md-6 col-lg-4 form-group first_order">
                                <label for="name" class="title-color font-weight-medium d-flex"><?php echo e(translate('coupon_bearer')); ?></label>
                                <select class="form-control" name="coupon_bearer" id="coupon_bearer" >
                                    <option disabled selected><?php echo e(translate('select_coupon_bearer')); ?></option>
                                    <option value="seller" <?php echo e($coupon['coupon_bearer']=='seller'?'selected':''); ?>><?php echo e(translate('vendor')); ?></option>
                                    <option value="inhouse" <?php echo e($coupon['coupon_bearer']=='inhouse'?'selected':''); ?>><?php echo e(translate('admin')); ?></option>
                                </select>
                            </div>
                            <div class="col-md-6 col-lg-4 form-group coupon_by first_order">
                                <label for="name" class="title-color font-weight-medium d-flex"><?php echo e(translate('vendor')); ?></label>
                                <select class="js-example-basic-multiple js-states js-example-responsive form-control" name="seller_id" id="vendor_wise_coupon">
                                    <option disabled selected><?php echo e(translate('select_Vendor')); ?></option>
                                    <option value="0" <?php echo e($coupon['seller_id']=='0'?'selected':''); ?>><?php echo e(translate('all_Vendor')); ?></option>
                                    <?php if($coupon['coupon_bearer'] == 'inhouse'): ?>
                                    <option value="inhouse" <?php echo e(is_null($coupon['seller_id'])?'selected':''); ?>><?php echo e(translate('inhouse')); ?></option>
                                    <?php endif; ?>
                                    <?php $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($seller->id); ?>" <?php echo e($coupon['seller_id']==$seller->id?'selected':''); ?>><?php echo e($seller->shop->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-6 col-lg-4 form-group coupon_type first_order">
                                <label for="name" class="title-color font-weight-medium d-flex"><?php echo e(translate('customer')); ?></label>
                                <select class="js-example-basic-multiple js-states js-example-responsive form-control" name="customer_id" >
                                    <option disabled selected><?php echo e(translate('select_customer')); ?></option>
                                    <option value="0" <?php echo e($coupon['customer_id']=='0'?'selected':''); ?>><?php echo e(translate('all_customer')); ?></option>
                                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($customer->id); ?>" <?php echo e($coupon['customer_id']==$customer->id ? 'selected':''); ?>><?php echo e($customer->f_name. ' '. $customer->l_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-6 col-lg-4 form-group first_order">
                                <label  for="exampleFormControlInput1" class="title-color text-capitalize"><?php echo e(translate('limit_for_same_user')); ?></label>
                                <input type="number" name="limit" min="0" value="<?php echo e($coupon['limit']); ?>" id="coupon_limit" class="form-control" placeholder="<?php echo e(translate('ex'.':'.'10')); ?>">
                            </div>
                            <div class="col-md-6 col-lg-4 form-group free_delivery">
                                <label  for="name" class="title-color text-capitalize"><?php echo e(translate('discount_type')); ?></label>
                                <select id="discount_type" class="form-control" name="discount_type">
                                    <option value="amount" <?php echo e($coupon['discount_type']=='amount'?'selected':''); ?>><?php echo e(translate('amount')); ?></option>
                                    <option value="percentage" <?php echo e($coupon['discount_type']=='percentage'?'selected':''); ?>><?php echo e(translate('percentage')); ?></option>
                                </select>
                            </div>
                            <div class="col-md-6 col-lg-4 form-group free_delivery">
                                <label for="name" class="title-color text-capitalize"><?php echo e(translate('discount_Amount')); ?> <span id="discount_percent"> (%)</span></label>
                                <input type="number" min="0" max="1000000" step=".01" name="discount" class="form-control" id="discount" value="<?php echo e($coupon['discount_type']=='amount'? currencyConverter(amount:$coupon['discount']):$coupon['discount']); ?>"
                                    placeholder="<?php echo e(translate('ex').':'.'500'); ?>" required>
                            </div>
                            <div class="col-md-6 col-lg-4 form-group">
                                <label for="name" class="title-color text-capitalize"><?php echo e(translate('minimum_purchase')); ?></label>
                                <input type="number" min="0" max="1000000" step=".01" name="min_purchase" class="form-control" id="minimum purchase" value="<?php echo e(currencyConverter(amount:$coupon['min_purchase'])); ?>"
                                       placeholder="<?php echo e(translate('minimum_purchase')); ?>" required>
                            </div>
                            <div class="col-md-6 col-lg-4 form-group free_delivery" id="max-discount">
                                <label for="name" class="title-color text-capitalize"><?php echo e(translate('maximum_discount')); ?></label>
                                <input type="number" min="0" max="1000000" step=".01" name="max_discount" class="form-control" id="maximum discount" value="<?php echo e(currencyConverter(amount:$coupon['max_discount'])); ?>"
                                       placeholder="<?php echo e(translate('maximum_discount')); ?>">
                            </div>
                            <div class="col-md-6 col-lg-4 form-group">
                                <label for="name" class="title-color text-capitalize"><?php echo e(translate('start_date')); ?></label>
                                <input type="date" name="start_date" class="form-control" id="start_date" value="<?php echo e(date('Y-m-d',strtotime($coupon['start_date']))); ?>"
                                       placeholder="<?php echo e(translate('start_date')); ?>" required>
                            </div>
                            <div class="col-md-6 col-lg-4 form-group">
                                <label for="name" class="title-color text-capitalize"><?php echo e(translate('expire_date')); ?></label>
                                <input type="date" name="expire_date" class="form-control" id="expire_date" value="<?php echo e(date('Y-m-d',strtotime($coupon['expire_date']))); ?>"
                                       placeholder="<?php echo e(translate('expire_date')); ?>" required>
                            </div>
                        </div>

                        <div class="d-flex align-items-center justify-content-end flex-wrap gap-10">
                            <button type="reset" class="btn btn-secondary px-4"><?php echo e(translate('reset')); ?></button>
                            <button type="submit" class="btn btn--primary px-4"><?php echo e(translate('Update')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<span id="coupon-bearer-url" data-url="<?php echo e(route('admin.coupon.ajax-get-seller')); ?>"></span>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('public/assets/back-end/js/admin/coupon.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.back-end.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/blunxtld/public_html/resources/views/admin-views/coupon/edit.blade.php ENDPATH**/ ?>