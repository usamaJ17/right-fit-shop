<?php $__env->startSection('title', translate('track_Order').' | '.$web_config['name']->value.' '.translate('ecommerce')); ?>

<?php $__env->startSection('content'); ?>
    <main class="main-content d-flex flex-column gap-3 py-3 mb-sm-5">
        <div class="container">
            <div class="card h-100">
                <div class="card-body py-4 px-sm-4">
                    <h2 class="mb-30 text-center"><?php echo e(translate('track_order')); ?></h2>
                    <form action="<?php echo e(route('track-order.result')); ?>" type="submit" method="post" class="p-sm-3">
                        <?php echo csrf_field(); ?>
                        <div class="d-flex flex-column flex-sm-row flex-wrap gap-3 align-items-sm-end">
                            <div class="flex-grow-1 d-flex gap-3">
                                <div class="form-group flex-grow-1">
                                    <label for="order_id"><?php echo e(translate('order_ID')); ?></label>
                                    <input type="text" id="order_id" name="order_id" class="form-control" value="<?php echo e(old('order_id')); ?>" placeholder="<?php echo e(translate('order_ID')); ?>">
                                </div>
                                <div class="form-group flex-grow-1">
                                    <label for="phone_or_email"><?php echo e(translate('phone')); ?></label>
                                    <input type="text" id="phone_or_email"  name="phone_number" class="form-control" value="<?php echo e(old('phone_number')); ?>" placeholder="<?php echo e(translate('phone')); ?>">
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary h-45 flex-grow-1"><?php echo e(translate('track_order')); ?></button>
                        </div>
                    </form>
                    <div class="text-center mt-5">
                        <img width="92" src="<?php echo e(theme_asset('assets/img/media/track-order.png')); ?>" class="dark-support mb-2" alt="<?php echo e(translate('image')); ?>">
                        <p class="text-muted"><?php echo e(translate('enter_your_order_ID_&_phone_to_get_delivery_updates')); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme-views.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/blunxtld/public_html/resources/themes/theme_aster/theme-views/order/tracking-page.blade.php ENDPATH**/ ?>