<span id="update_nav_cart_url" data-url="<?php echo e(route('cart.nav-cart')); ?>"></span>
<span id="remove_from_cart_url" data-url="<?php echo e(route('cart.remove')); ?>"></span>
<span id="update-quantity-basic-url" data-url="<?php echo e(route('cart.updateQuantity')); ?>"></span>
<span id="checkout_details_url" data-url="<?php echo e(route('checkout-details')); ?>"></span>
<span id="order_note_url" data-url="<?php echo e(route('order_note')); ?>"></span>
<span id="update_quantity_url" data-url="<?php echo e(route('cart.updateQuantity.guest')); ?>"></span>
<span id="get-place-holder-image" data-src="<?php echo e(theme_asset('assets/img/image-place-holder.png')); ?>"></span>
<span id="authentication-status" data-auth="<?php echo e(auth('customer')->check() ? 'true' : 'false'); ?>"></span>
<span id="set-shipping-url" data-url="<?php echo e(url('/')); ?>/customer/set-shipping-method"></span>
<span id="digital-product-download-otp-reset" data-route="<?php echo e(route('digital-product-download-otp-reset')); ?>"></span>
<span id="order_again_url" data-action="<?php echo e(route('cart.order-again')); ?>"></span>
<?php /**PATH /home/blunxtld/public_html/resources/themes/theme_aster/theme-views/layouts/partials/_route-for-js.blade.php ENDPATH**/ ?>