<?php
    use function App\Utils\customer_info;
    $customer_info = customer_info();
?>
<div class="col-lg-3">
    <div class="card profile-sidebar-sticky">
        <div class="card-body position-relative">
            <div class="d-none d-lg-flex justify-content-end">
                <div class="dropdown">
                    <button class="btn-circle p-0 bg-primary absolute-white size-1-125rem" type="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-three-dots fs-10 grid-center"></i>
                    </button>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="javascript:" class="delete-action"
                               data-action="<?php echo e(route('account-delete',[$customer_info['id']])); ?>"
                               data-text="<?php echo e(translate('want_to_delete_this_account').'?'); ?>">
                                <?php echo e(translate('delete_my_account')); ?>

                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div
                class="d-lg-none bg-primary rounded px-1 text-white cursor-pointer position-absolute end-1 top-1 profile-menu-toggle">
                <i class="bi bi-list fs-18"></i>
            </div>
            <div class="d-flex flex-row flex-lg-column gap-2 gap-lg-4 align-items-center">
                <div class="avatar overflow-hidden profile-sidebar-avatar border border-primary rounded-circle p-1">
                    <img class="img-fit dark-support rounded-circle"
                         src="<?php echo e(getValidImage(path: 'storage/app/public/profile/'.$customer_info->image, type:'avatar')); ?>" alt="">
                </div>

                <div class="text-lg-center">
                    <h5 class="mb-1"><?php echo e($customer_info->f_name); ?> <?php echo e($customer_info->l_name); ?></h5>
                    <p class="fw-medium"><?php echo e(translate('joined')); ?> <?php echo e(date('d M, Y',strtotime($customer_info->created_at))); ?></p>
                </div>
            </div>
            <div class="profile-menu-aside">
                <div class="profile-menu-aside-close d-lg-none">
                    <i class="bi bi-x-lg text-primary"></i>
                </div>
                <ul class="list-unstyled profile-menu gap-1 mt-3">
                    <li class="<?php echo e(Request::is('user-profile') || Request::is('user-account') ||Request::is('account-address-*') ? 'active' :''); ?>">
                        <a href="<?php echo e(route('user-profile')); ?>">
                            <img width="20" src="<?php echo e(theme_asset('assets/img/icons/profile-icon.png')); ?>"
                                 class="dark-support" alt="">
                            <span class="text-capitalize"><?php echo e(translate('my_profile')); ?></span>
                        </a>
                    </li>
                    <li class="<?php echo e(Request::is('account-oder*') || Request::is('account-order-details*') || Request::is('refund-details*') || Request::is('track-order/order-wise-result-view') ? 'active' :''); ?>">
                        <a href="<?php echo e(route('account-oder')); ?>">
                            <img width="20" src="<?php echo e(theme_asset('assets/img/icons/profile-icon2.png')); ?>"
                                 class="dark-support" alt="">
                            <span><?php echo e(translate('Orders')); ?></span>
                        </a>
                    </li>
                    <li class="<?php echo e(Request::is('wishlists') ? 'active' :''); ?>">
                        <a href="<?php echo e(route('wishlists')); ?>">
                            <img width="20" src="<?php echo e(theme_asset('assets/img/icons/profile-icon3.png')); ?>"
                                 class="dark-support" alt="">
                            <span><?php echo e(translate('Wish_List')); ?></span>
                        </a>
                    </li>
                    <li class="<?php echo e(Request::is('product-compare/index') ? 'active' :''); ?>">
                        <a href="<?php echo e(route('product-compare.index')); ?>">
                            <img width="20" src="<?php echo e(theme_asset('assets/img/icons/profile-icon4.png')); ?>"
                                 class="dark-support" alt="">
                            <span><?php echo e(translate('Compare_List')); ?></span>
                        </a>
                    </li>

                    <?php if($web_config['wallet_status'] == 1): ?>
                        <li class="<?php echo e(Request::is('wallet') ? 'active' :''); ?>">
                            <a href="<?php echo e(route('wallet')); ?>">
                                <img width="20" src="<?php echo e(theme_asset('assets/img/icons/profile-icon5.png')); ?>"
                                     class="dark-support" alt="">
                                <span><?php echo e(translate('wallet')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if($web_config['loyalty_point_status'] == 1): ?>
                        <li class="<?php echo e(Request::is ('loyalty') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('loyalty')); ?>">
                                <img width="20" src="<?php echo e(theme_asset('assets/img/icons/profile-icon6.png')); ?>"
                                     class="dark-support" alt="">
                                <span class="text-capitalize"><?php echo e(translate('loyalty_point')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <li class="<?php echo e(Request::is ('chat/seller') || Request::is ('chat/delivery-man') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('chat', ['type' => 'seller'])); ?>">
                            <img width="20" src="<?php echo e(theme_asset('assets/img/icons/profile-icon7.png')); ?>"
                                 class="dark-support" alt="">
                            <span><?php echo e(translate('inbox')); ?></span>
                        </a>
                    </li>
                    <li class="<?php echo e(Request::is ('account-tickets') || Request::is('support-ticket*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('account-tickets')); ?>">
                            <img width="20" src="<?php echo e(theme_asset('assets/img/icons/profile-icon8.png')); ?>"
                                 class="dark-support" alt="">
                            <span class="text-capitalize"><?php echo e(translate('support_ticket')); ?></span>
                        </a>
                    </li>
                    <?php if($web_config['ref_earning_status']): ?>
                        <li class="<?php echo e(Request::is ('refer-earn') || Request::is('refer-earn*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('refer-earn')); ?>">
                                <img width="20" src="<?php echo e(theme_asset('assets/img/icons/refer-and-earn.svg')); ?>"
                                     class="dark-support" alt="">
                                <span><?php echo e(translate('refer_&_earn')); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <li class="<?php echo e(Request::is ('user-coupons') || Request::is('user-coupons*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('user-coupons')); ?>">
                            <img width="20" src="<?php echo e(theme_asset('assets/img/icons/coupon.svg')); ?>" class="dark-support"
                                 alt="">
                            <span><?php echo e(translate('coupons')); ?></span>
                        </a>
                    </li>
                    <li class="d-lg-none">
                        <a class="d-flex align-items-center" href="javascript:"
                           class="delete-action"
                           data-action="<?php echo e(route('account-delete',[$customer_info['id']])); ?>"
                           data-text="<?php echo e(translate('want_to_delete_this_account').'?'); ?>">
                            <i class="bi bi-trash3-fill text-danger fs-16"></i>
                            <?php echo e(translate('delete_my_account')); ?>

                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/blunxtld/public_html/resources/themes/theme_aster/theme-views/partials/_profile-aside.blade.php ENDPATH**/ ?>