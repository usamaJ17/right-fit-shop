<?php $__env->startSection('title', translate('profile_Settings')); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <div class="page-header">
            <div class="row align-items-end">
                <h2 class="col-sm mb-2 mb-sm-0 h1 mb-0 text-capitalize d-flex align-items-center gap-2">
                    <img width="20" src="<?php echo e(asset('/public/assets/back-end/img/profile_setting.png')); ?>" alt="">
                    <?php echo e(translate('settings')); ?>

                </h2>
                <div class="col-sm-auto">
                    <a class="btn btn--primary" href="<?php echo e(route('admin.dashboard')); ?>">
                        <i class="tio-home mr-1"></i> <?php echo e(translate('dashboard')); ?>

                    </a>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-3">
                <div class="navbar-vertical navbar-expand-lg mb-3 mb-lg-5">
                    <button type="button" class="navbar-toggler btn btn-block btn-white mb-3"
                            aria-label="Toggle navigation" aria-expanded="false" aria-controls="navbarVerticalNavMenu"
                            data-toggle="collapse" data-target="#navbarVerticalNavMenu">
                <span class="d-flex justify-content-between align-items-center">
                  <span class="h5 mb-0"><?php echo e(translate('nav_menu')); ?></span>
                  <span class="navbar-toggle-default">
                    <i class="tio-menu-hamburger"></i>
                  </span>
                  <span class="navbar-toggle-toggled">
                    <i class="tio-clear"></i>
                  </span>
                </span>
                    </button>
                    <div id="navbarVerticalNavMenu" class="collapse navbar-collapse">
                        <ul id="navbarSettings"
                            class="js-sticky-block js-scrollspy navbar-nav navbar-nav-lg nav-tabs card card-navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link active" href="javascript:" id="general-section">
                                    <i class="tio-user-outlined nav-icon"></i><?php echo e(translate('basic_Information')); ?>

                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="javascript:" id="password-section">
                                    <i class="tio-lock-outlined nav-icon"></i> <?php echo e(translate('password')); ?>

                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-lg-9">
                <form action="<?php echo e(route('admin.profile.update',[$admin->id])); ?>" method="post" enctype="multipart/form-data" id="admin-profile-form">
                <?php echo csrf_field(); ?>
                    <div class="card mb-3 mb-lg-5" id="general-div">
                        <div class="profile-cover">
                            <?php ($banner = !empty($shopBanner) ? asset('storage/app/public/shop/'.$shopBanner) : asset('public/assets/back-end/img/1920x400/img2.jpg')); ?>
                            <div class="profile-cover-img-wrapper profile-bg" style="background-image: url(<?php echo e($banner); ?>)"></div>
                        </div>
                        <label
                            class="avatar avatar-xxl avatar-circle avatar-border-lg avatar-uploader profile-cover-avatar"
                            for="custom-file-upload">
                            <img id="viewer"
                                 src="<?php echo e(getValidImage(path:'storage/app/public/admin/'.$admin->image,type: 'backend-profile')); ?>"
                                 class="avatar-img"
                                 alt="<?php echo e(translate('image')); ?>">
                        </label>
                    </div>
                    <div class="card mb-3 mb-lg-5">
                        <div class="card-header">
                            <h2 class="card-title h4 text-capitalize"><?php echo e(translate('basic_information')); ?></h2>
                        </div>
                        <div class="card-body">
                            <div class="row form-group">
                                <label for="firstNameLabel" class="col-sm-3 col-form-label input-label">
                                    <?php echo e(translate('full_name')); ?>

                                    <i class="tio-help-outlined text-body ml-1"
                                        title="<?php echo e(translate('display_name')); ?>">
                                    </i>
                                </label>

                                <div class="col-sm-9">
                                    <div class="input-group input-group-sm-down-break">
                                        <input type="text" class="form-control" name="name" id="firstNameLabel"
                                               placeholder="<?php echo e(translate('your_first_name')); ?>" aria-label="Your first name"
                                               value="<?php echo e($admin->name); ?>">

                                    </div>
                                </div>
                            </div>
                            <div class="row form-group">
                                <label for="phoneLabel" class="col-sm-3 col-form-label input-label"><?php echo e(translate('phone')); ?> <span
                                        class="input-label-secondary">(<?php echo e(translate('optional')); ?>)</span></label>

                                <div class="col-sm-9">
                                    <input type="text" class="js-masked-input form-control" name="phone" id="phoneLabel"
                                           placeholder="<?php echo e(translate('+x(xxx)xxx-xx-xx')); ?>"
                                           value="<?php echo e($admin->phone); ?>">
                                </div>
                            </div>
                            <div class="row form-group">
                                <label for="newEmailLabel" class="col-sm-3 col-form-label input-label"><?php echo e(translate('email')); ?></label>
                                <div class="col-sm-9">
                                    <input type="email" class="form-control" name="email" id="newEmailLabel"
                                           value="<?php echo e($admin->email); ?>"
                                           placeholder="<?php echo e(translate('enter_new_email_address')); ?>">
                                </div>
                            </div>
                            <div class="row">
                                <label for="newEmailLabel" class="col-sm-3 input-label text-capitalize"><?php echo e(translate('profile_image')); ?></label>
                                <div class="form-group col-md-9" id="select-img">
                                    <span class="d-block mb-2 text-info">( <?php echo e(translate('ratio').' '.'1:1'); ?>)</span>
                                    <div class="custom-file">
                                        <input type="file" name="image" id="custom-file-upload" data-image-id="viewer" class="custom-file-input  image-input"
                                            accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*">
                                        <label class="custom-file-label text-capitalize" for="custom-file-upload"><?php echo e(translate('image_upload')); ?></label>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-end">
                                <button type="button" data-id="admin-profile-form" data-message="<?php echo e(translate('want_to_update_admin_info').'?'); ?>" class="btn btn--primary <?php echo e(env('APP_MODE')!='demo'?'form-alert':'call-demo'); ?>"><?php echo e(translate('save_changes')); ?></button>
                            </div>
                        </div>
                    </div>
                </form>
                <div id="password-div" class="card mb-3 mb-lg-5">
                    <div class="card-header">
                        <h4 class="card-title"><?php echo e(translate('change_your_password')); ?></h4>
                    </div>
                    <div class="card-body">
                        <form id="change-password-form" action="<?php echo e(route('admin.profile.update',[$admin->id])); ?>" method="post"
                              enctype="multipart/form-data">
                        <?php echo csrf_field(); ?> <?php echo method_field('patch'); ?>
                            <div class="row form-group">
                                <label for="newPassword" class="col-sm-3 col-form-label input-label"> <?php echo e(translate('new_password')); ?></label>

                                <div class="col-sm-9">
                                    <input type="password" class="js-pwstrength form-control" name="password"
                                           id="newPassword" placeholder="<?php echo e(translate('enter_new_password')); ?>">
                                </div>
                            </div>
                            <div class="row form-group">
                                <label for="confirmNewPasswordLabel" class="col-sm-3 col-form-label input-label"> <?php echo e(translate('confirm_password')); ?> </label>

                                <div class="col-sm-9">
                                    <div class="mb-3">
                                        <input type="password" class="form-control" name="confirm_password"
                                               id="confirmNewPasswordLabel" placeholder="<?php echo e(translate('confirm_your_new_password')); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-end">
                                <button type="button" data-id="change-password-form" data-message="<?php echo e(translate('want_to_update_admin_password').'?'); ?>" class="btn btn--primary <?php echo e(env('APP_MODE')!='demo'?'form-alert':'call-demo'); ?>"><?php echo e(translate('save_changes')); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.back-end.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/blunxtld/public_html/resources/views/admin-views/profile/update-view.blade.php ENDPATH**/ ?>