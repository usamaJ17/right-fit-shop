<?php $__env->startSection('title', translate('shopping_Details').' | '.$web_config['name']->value.' '.translate('ecommerce')); ?>

<?php $__env->startSection('content'); ?>
    <main class="main-content d-flex flex-column gap-3 py-3 mb-5">
        <div class="container">
            <h4 class="text-center mb-3 text-capitalize"><?php echo e(translate('shipping_details')); ?></h4>
            <div class="row">
                <div class="col-lg-8 mb-3 mb-lg-0">
                    <div class="card h-100">
                        <div class="card-body  px-sm-4">
                            <div class="d-flex justify-content-center mb-30">
                                <ul class="cart-step-list">
                                    <li class="done cursor-pointer get-view-by-onclick"
                                        data-link="<?php echo e(route('shop-cart')); ?>"><span><i
                                                class="bi bi-check2"></i></span> <?php echo e(translate('cart')); ?></li>
                                    <li class="current cursor-pointer get-view-by-onclick text-capitalize"
                                        data-link="<?php echo e(route('checkout-details')); ?>"><span><i
                                                class="bi bi-check2"></i></span> <?php echo e(translate('shipping_details')); ?>

                                    </li>
                                    <li><span><i class="bi bi-check2"></i></span> <?php echo e(translate('payment')); ?></li>
                                </ul>
                            </div>
                            <input type="hidden" id="physical-product" name="physical_product"
                                   value="<?php echo e($physical_product_view ? 'yes':'no'); ?>">
                            <input type="hidden" id="billing-input-enable" name="billing_input_enable"
                                   value="<?php echo e($billing_input_by_customer); ?>">
                            <?php if($physical_product_view): ?>
                                <form method="post" id="address-form">
                                    <h5 class="mb-3 text-capitalize"><?php echo e(translate('delivery_information_details')); ?></h5>
                                    <div class="d-flex flex-wrap justify-content-between gap-3 mb-3">
                                        <div class="d-flex flex-wrap gap-3 align-items-center">
                                            <h6 class="text-capitalize"><?php echo e(translate('delivery_address')); ?></h6>
                                        </div>
                                        <div class="d-flex flex-wrap gap-3 align-items-center">
                                            <a href="javascript:" type="button" data-bs-toggle="modal"
                                               data-bs-target="#shippingMapModal"
                                               class="btn-link text-primary text-capitalize"><?php echo e(translate('set_form_map')); ?>

                                                <i class="bi bi-geo-alt-fill"></i></a>
                                            <?php if(auth('customer')->check()): ?>
                                                <a href="javascript:" type="button" data-bs-toggle="modal"
                                                   data-bs-target="#shippingSavedAddressModal"
                                                   class="btn-link text-primary text-capitalize"><?php echo e(translate('select_from_saved')); ?></a>
                                            <?php endif; ?>
                                            <div class="modal fade" id="shippingMapModal" tabindex="-1"
                                                 aria-hidden="true">
                                                <div class="modal-dialog modal-lg modal-dialog-centered">
                                                    <div class="modal-content">
                                                        <div class="modal-body">
                                                            <div class="product-quickview">
                                                                <button type="button" class="btn-close outside"
                                                                        data-bs-dismiss="modal"
                                                                        aria-label="Close"></button>
                                                                <input id="pac-input"
                                                                       class="controls rounded __inline-46"
                                                                       title="<?php echo e(translate('search_your_location_here')); ?>"
                                                                       type="text"
                                                                       placeholder="<?php echo e(translate('search_here')); ?>"/>
                                                                <div class="dark-support rounded w-100 __h-14rem"
                                                                     id="location_map_canvas"></div>
                                                                <input type="hidden" id="latitude"
                                                                       name="latitude" class="form-control d-inline"
                                                                       placeholder="<?php echo e(translate('ex')); ?> : <?php echo e(translate('-94.22213')); ?>"
                                                                       value="<?php echo e($default_location?$default_location['lat']:0); ?>"
                                                                       required readonly>
                                                                <input type="hidden"
                                                                       name="longitude" class="form-control"
                                                                       placeholder="<?php echo e(translate('ex')); ?> : <?php echo e(translate('103.344322')); ?>"
                                                                       id="longitude"
                                                                       value="<?php echo e($default_location?$default_location['lng']:0); ?>"
                                                                       required>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <?php if(auth('customer')->check()): ?>
                                        <div class="modal fade" id="shippingSavedAddressModal" data-bs-backdrop="static"
                                             data-bs-keyboard="false" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered justify-content-center">
                                                <div class="modal-content border-0">
                                                    <div class="modal-header">
                                                        <h5 class="text-capitalize"
                                                            id="contact_sellerModalLabel"><?php echo e(translate('saved_addresses')); ?></h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                                aria-label="Close"></button>
                                                    </div>

                                                    <div class="modal-body custom-scrollbar">
                                                        <div class="product-quickview">
                                                            <div
                                                                class="shipping-saved-addresses <?php echo e($shipping_addresses->count()<1 ? 'd--none':''); ?>">
                                                                <div class="row gy-3 text-dark py-4">
                                                                    <?php $__currentLoopData = $shipping_addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <div class="col-md-12">
                                                                            <div class="card border-0">
                                                                                <div
                                                                                    class="card-header bg-transparent gap-2 align-items-center d-flex flex-wrap justify-content-between">
                                                                                    <label
                                                                                        class="d-flex align-items-center gap-3 cursor-pointer mb-0">
                                                                                        <input type="radio"
                                                                                               name="shipping_method_id"
                                                                                               value="<?php echo e($address['id']); ?>" <?php echo e($key==0?'checked':''); ?>>
                                                                                        <h6><?php echo e($address['address_type']); ?></h6>
                                                                                    </label>
                                                                                    <div
                                                                                        class="d-flex align-items-center gap-3">
                                                                                        <button type="button"
                                                                                                onclick="location.href='<?php echo e(route('address-edit', ['id' => $address->id])); ?>'"
                                                                                                class="p-0 bg-transparent border-0">
                                                                                            <img
                                                                                                src="<?php echo e(theme_asset('assets/img/svg/location-edit.svg')); ?>"
                                                                                                alt="" class="svg">
                                                                                        </button>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="card-body">
                                                                                    <address>
                                                                                        <dl class="mb-0 flexible-grid sm-down-1 width--5rem">
                                                                                            <dt><?php echo e(translate('name')); ?></dt>
                                                                                            <dd class="shipping-contact-person"><?php echo e($address['contact_person_name']); ?></dd>

                                                                                            <dt><?php echo e(translate('phone')); ?></dt>
                                                                                            <dd class="">
                                                                                                <a href="tel:<?php echo e($address['phone']); ?>"
                                                                                                   class="text-dark shipping-contact-phone"><?php echo e($address['phone']); ?></a>
                                                                                            </dd>

                                                                                            <dt><?php echo e(translate('address')); ?></dt>
                                                                                            <dd><?php echo e($address['address']); ?>

                                                                                                , <?php echo e($address['city']); ?>

                                                                                                , <?php echo e($address['zip']); ?></dd>
                                                                                            <span
                                                                                                class="shipping-contact-address d-none"><?php echo e($address['address']); ?></span>
                                                                                            <span
                                                                                                class="shipping-contact-city d-none"><?php echo e($address['city']); ?></span>
                                                                                            <span
                                                                                                class="shipping-contact-zip d-none"><?php echo e($address['zip']); ?></span>
                                                                                            <span
                                                                                                class="shipping-contact-country d-none"><?php echo e($address['country']); ?></span>
                                                                                            <span
                                                                                                class="shipping-contact-address-type d-none"><?php echo e($address['address_type']); ?></span>
                                                                                        </dl>
                                                                                    </address>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </div>
                                                            </div>
                                                            <div
                                                                class="text-center <?php echo e($shipping_addresses->count()>0 ? 'd--none':''); ?>">
                                                                <img src="<?php echo e(theme_asset('assets/img/svg/address.svg')); ?>"
                                                                     alt="address" class="w-25">
                                                                <h5 class="my-3 pt-1 text-muted">
                                                                    <?php echo e(translate('no_address_is_saved')); ?>!
                                                                </h5>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                                data-bs-dismiss="modal"><?php echo e(translate('close')); ?></button>
                                                        <button type="button" class="btn btn-primary"
                                                                data-bs-dismiss="modal"><?php echo e(translate('save')); ?></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                    <div class="card">
                                        <div class="card-body" id="collapseThree">
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="row mb-30">
                                                        <div
                                                            class="col-sm-<?php if(auth('customer')->check()): ?> '6' <?php else: ?> '12' <?php endif; ?>">
                                                            <div class="form-group mb-3">
                                                                <label for="name"
                                                                       class="text-capitalize"><?php echo e(translate('contact_person_name')); ?></label>
                                                                <input type="text" name="contact_person_name" id="name"
                                                                       class="form-control"
                                                                       placeholder="<?php echo e(translate('ex')); ?>: <?php echo e(translate('Jhon_Doe')); ?>" <?php echo e($shipping_addresses->count()==0?'required':''); ?>>
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-6">
                                                            <div class="form-group mb-3">
                                                                <label for="phone"><?php echo e(translate('phone')); ?></label>
                                                                <input type="tel" name="phone" id="phoneNumber"
                                                                       class="form-control"
                                                                       placeholder="<?php echo e(translate('ex')); ?>: <?php echo e(translate('+8801000000000')); ?>" <?php echo e($shipping_addresses->count()==0?'required':''); ?>>
                                                            </div>
                                                        </div>
                                                        <?php if(!auth('customer')->check()): ?>
                                                            <div class="col-sm-6">
                                                                <div class="form-group mb-3">
                                                                    <label for="email"><?php echo e(translate('email')); ?></label>
                                                                    <input type="email" name="email" id="email"
                                                                           class="form-control"
                                                                           placeholder="<?php echo e(translate('ex')); ?>: <?php echo e(translate('email@domain.com')); ?>"
                                                                           required>
                                                                </div>
                                                            </div>
                                                        <?php endif; ?>
                                                        <div class="col-sm-6">
                                                            <div class="form-group mb-3">
                                                                <label for="address-type"
                                                                       class="text-capitalize"><?php echo e(translate('address_type')); ?></label>
                                                                <select name="address_type" id="address-type"
                                                                        class="form-select">
                                                                    <option
                                                                        value="permanent"><?php echo e(translate('permanent')); ?></option>
                                                                    <option value="home"><?php echo e(translate('home')); ?></option>
                                                                    <option
                                                                        value="others"><?php echo e(translate('others')); ?></option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-6">
                                                            <div class="form-group mb-3">
                                                                <label for="country"><?php echo e(translate('country')); ?></label>
                                                                <select name="country" id="country"
                                                                        class="form-control select_picker select2">
                                                                    <?php $__empty_1 = true; $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                        <option
                                                                            value="<?php echo e($country['name']); ?>"><?php echo e($country['name']); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                        <option
                                                                            value=""><?php echo e(translate('no_country_to_deliver')); ?></option>
                                                                    <?php endif; ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-6">
                                                            <div class="form-group mb-3">
                                                                <label for="city"><?php echo e(translate('city')); ?></label>
                                                                <input type="text" name="city" id="city"
                                                                       placeholder="<?php echo e(translate('ex')); ?>: <?php echo e(translate('dhaka')); ?>"
                                                                       class="form-control" <?php echo e($shipping_addresses->count()==0?'required':''); ?>>
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-6">
                                                            <div class="form-group mb-3">
                                                                <label for="city"
                                                                       class="text-capitalize"><?php echo e(translate('zip_code')); ?></label>
                                                                <?php if($zip_restrict_status == 1): ?>
                                                                    <select name="zip" id="zip"
                                                                            class="form-control select2 select_picker"
                                                                            data-live-search="true" required>
                                                                        <?php $__empty_1 = true; $__currentLoopData = $zip_codes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                            <option
                                                                                value="<?php echo e($code->zipcode); ?>"><?php echo e($code->zipcode); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                            <option
                                                                                value=""><?php echo e(translate('no_zip_to_deliver')); ?></option>
                                                                        <?php endif; ?>
                                                                    </select>
                                                                <?php else: ?>
                                                                    <input type="text" class="form-control" id="zip"
                                                                           name="zip"
                                                                           placeholder="<?php echo e(translate('ex')); ?>: <?php echo e(translate('1216')); ?>" <?php echo e($shipping_addresses->count()==0?'required':''); ?>>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-12">
                                                            <div class="form-group mb-3">
                                                                <label for="address"><?php echo e(translate('address')); ?></label>
                                                                <div
                                                                    class="form-control focus-border rounded d-flex align-items-center">
                                                                    <input type="text" name="address" id="address"
                                                                           class="flex-grow-1 text-dark bg-transparent border-0 focus-input"
                                                                           placeholder="<?php echo e(translate('your_address')); ?>" <?php echo e($shipping_addresses->count()==0?'required':''); ?>>
                                                                    <div class="border-start ps-3 pe-1"
                                                                         data-bs-toggle="modal"
                                                                         data-bs-target="#shippingMapModal">
                                                                        <i class="bi bi-compass-fill"></i>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="col-sm-12">
                                                            <label class="custom-checkbox align-items-center"
                                                                   id="save-address-label">
                                                                <input type="hidden" name="shipping_method_id"
                                                                       id="shipping-method-id" value="0">
                                                                <?php if(auth('customer')->check()): ?>
                                                                    <input type="checkbox" name="save_address"
                                                                           id="saveAddress">
                                                                    <?php echo e(translate('save_this_address')); ?>

                                                                <?php endif; ?>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </form>
                            <?php endif; ?>
                            <?php if($billing_input_by_customer): ?>
                                <div class="mt-5 <?php echo e($billing_input_by_customer ? '':'d-none'); ?>">
                                    <div class="bg-light rounded p-3 mt-20">
                                        <div class="d-flex flex-wrap justify-content-between gap-3">
                                            <div class="d-flex gap-3 align-items-center">
                                                <h6 class="text-capitalize"><?php echo e(translate('billing_address')); ?></h6>
                                            </div>

                                            <?php if($physical_product_view): ?>
                                                <label class="custom-checkbox" class="text-capitalize">
                                                    <?php echo e(translate('same_as_delivery_address')); ?>

                                                    <input type="checkbox" id="same-as-shipping-address"
                                                           name="same_as_shipping_address"
                                                           class="billing-address-checkbox" <?php echo e($billing_input_by_customer==1?'':'checked'); ?>>
                                                </label>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <form method="post" id="billing-address-form">
                                        <div class="toggle-billing-address mt-3" id="hide-billing-address">
                                            <div class="d-flex flex-wrap justify-content-between gap-3 mb-3">
                                                <div class="d-flex flex-wrap gap-3 align-items-center">
                                                </div>
                                                <div class="d-flex flex-wrap gap-3 align-items-center">
                                                    <a href="javascript:" data-bs-toggle="modal"
                                                       data-bs-target="#billingMapModal"
                                                       class="btn-link text-primary text-capitalize"><?php echo e(translate('set_form_map')); ?>

                                                        <i class="bi bi-geo-alt-fill"></i></a>
                                                    <div class="modal fade" id="billingMapModal" tabindex="-1"
                                                         aria-hidden="true">
                                                        <div class="modal-dialog modal-lg modal-dialog-centered">
                                                            <div class="modal-content">
                                                                <div class="modal-body">
                                                                    <div class="product-quickview">
                                                                        <button type="button" class="btn-close outside"
                                                                                data-bs-dismiss="modal"
                                                                                aria-label="Close"></button>
                                                                        <input id="pac-input-billing"
                                                                               class="controls rounded __inline-46"
                                                                               title="<?php echo e(translate('search_your_location_here')); ?>"
                                                                               type="text"
                                                                               placeholder="<?php echo e(translate('search_here')); ?>"/>
                                                                        <div
                                                                            class="dark-support rounded w-100 __h-14rem"
                                                                            id="billing-location-map-canvas"></div>
                                                                        <input type="hidden" id="billing-latitude"
                                                                               name="billing_latitude"
                                                                               class="form-control d-inline"
                                                                               placeholder="<?php echo e(translate('ex')); ?> : <?php echo e(translate('-94.22213')); ?>"
                                                                               value="<?php echo e($default_location?$default_location['lat']:0); ?>"
                                                                               required readonly>
                                                                        <input type="hidden"
                                                                               name="billing_longitude"
                                                                               class="form-control"
                                                                               placeholder="<?php echo e(translate('ex')); ?> : <?php echo e(translate('103.344322')); ?>"
                                                                               id="billing-longitude"
                                                                               value="<?php echo e($default_location?$default_location['lng']:0); ?>"
                                                                               required>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <?php if(auth('customer')->check()): ?>
                                                        <a href="javascript:" type="button" data-bs-toggle="modal"
                                                           data-bs-target="#billingSavedAddressModal"
                                                           class="btn-link text-primary text-capitalize"><?php echo e(translate('select_from_saved')); ?></a>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <?php if(auth('customer')->check()): ?>
                                                <div class="modal fade" id="billingSavedAddressModal"
                                                     data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                                                     aria-hidden="true">
                                                    <div
                                                        class="modal-dialog modal-lg modal-dialog-centered justify-content-center">
                                                        <div class="modal-content border-0 max-width-500">
                                                            <div class="modal-header">
                                                                <h5 class="text-capitalize"
                                                                    id="contact_sellerModalLabel"><?php echo e(translate('saved_addresses')); ?></h5>
                                                                <button type="button" class="btn-close"
                                                                        data-bs-dismiss="modal"
                                                                        aria-label="Close"></button>
                                                            </div>

                                                            <div class="modal-body custom-scrollbar">
                                                                <div class="product-quickview">
                                                                    <div
                                                                        class="billing-saved-addresses <?php echo e($billing_addresses->count()<1 ? 'd--none':''); ?>">
                                                                        <div class="row gy-3 text-dark py-4">
                                                                            <?php $__currentLoopData = $billing_addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <div class="col-md-12">
                                                                                    <div class="card border-0 ">
                                                                                        <div
                                                                                            class="card-header bg-transparent gap-2 align-items-center d-flex flex-wrap justify-content-between">
                                                                                            <label
                                                                                                class="d-flex align-items-center gap-3 cursor-pointer mb-0">
                                                                                                <input type="radio"
                                                                                                       value="<?php echo e($address['id']); ?>"
                                                                                                       name="billing_method_id" <?php echo e($key==0?'checked':''); ?>>
                                                                                                <h6><?php echo e($address['address_type']); ?></h6>
                                                                                            </label>
                                                                                            <div
                                                                                                class="d-flex align-items-center gap-3">
                                                                                                <button type="button"
                                                                                                        onclick="location.href='<?php echo e(route('address-edit', ['id' => $address->id])); ?>'"
                                                                                                        class="p-0 bg-transparent border-0">
                                                                                                    <img
                                                                                                        src="<?php echo e(theme_asset('assets/img/svg/location-edit.svg')); ?>"
                                                                                                        alt=""
                                                                                                        class="svg">
                                                                                                </button>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="card-body pb-0">
                                                                                            <address>
                                                                                                <dl class="mb-0 flexible-grid sm-down-1 width--5rem">
                                                                                                    <dt><?php echo e(translate('name')); ?></dt>
                                                                                                    <dd class="billing-contact-name"><?php echo e($address['contact_person_name']); ?></dd>

                                                                                                    <dt><?php echo e(translate('phone')); ?></dt>
                                                                                                    <dd class="">
                                                                                                        <a href="tel:<?php echo e($address['phone']); ?>"
                                                                                                           class="text-dark billing-contact-phone"><?php echo e($address['phone']); ?></a>
                                                                                                    </dd>

                                                                                                    <dt><?php echo e(translate('address')); ?></dt>
                                                                                                    <dd><?php echo e($address['address']); ?>

                                                                                                        , <?php echo e($address['city']); ?>

                                                                                                        , <?php echo e($address['zip']); ?></dd>
                                                                                                    <span
                                                                                                        class="billing-contact-address d-none"><?php echo e($address['address']); ?></span>
                                                                                                    <span
                                                                                                        class="billing-contact-city d-none"><?php echo e($address['city']); ?></span>
                                                                                                    <span
                                                                                                        class="billing-contact-zip d-none"><?php echo e($address['zip']); ?></span>
                                                                                                    <span
                                                                                                        class="billing-contact-country d-none"><?php echo e($address['country']); ?></span>
                                                                                                    <span
                                                                                                        class="billing-contact-address-type d-none"><?php echo e($address['address_type']); ?></span>
                                                                                                </dl>
                                                                                            </address>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </div>
                                                                    </div>
                                                                    <div
                                                                        class="text-center <?php echo e($billing_addresses->count()>0 ? 'd--none':''); ?>">
                                                                        <img
                                                                            src="<?php echo e(theme_asset('assets/img/svg/address.svg')); ?>"
                                                                            alt="address" class="w-25">
                                                                        <h5 class="my-3 pt-1 text-muted">
                                                                            <?php echo e(translate('no_address_is_saved')); ?>!
                                                                        </h5>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary"
                                                                        data-bs-dismiss="modal"><?php echo e(translate('close')); ?></button>
                                                                <button type="button" class="btn btn-primary"
                                                                        data-bs-dismiss="modal"><?php echo e(translate('save')); ?></button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            <div class="card">
                                                <div class="card-body">
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <div class="row mb-30">
                                                                <div
                                                                    class="col-sm-<?php if(auth('customer')->check()): ?> '6' <?php else: ?> '12' <?php endif; ?>">
                                                                    <div class="form-group mb-3">
                                                                        <label for="billing-contact-person-name"
                                                                               class="text-capitalize"><?php echo e(translate('contact_person_name')); ?></label>
                                                                        <input type="text"
                                                                               name="billing_contact_person_name"
                                                                               id="billing-contact-person-name"
                                                                               class="form-control"
                                                                               placeholder="<?php echo e(translate('ex')); ?>: <?php echo e(translate('Jhon_Doe')); ?>" <?php echo e($billing_addresses->count()==0?'required':''); ?>>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-6">
                                                                    <div class="form-group mb-3">
                                                                        <label
                                                                            for="billing_phone"><?php echo e(translate('phone')); ?></label>
                                                                        <input type="tel" name="billing_phone"
                                                                               id="billing-phone" class="form-control"
                                                                               placeholder="<?php echo e(translate('ex')); ?>: <?php echo e(translate('+88 01000000000')); ?>" <?php echo e($billing_addresses->count()==0?'required':''); ?>>
                                                                    </div>
                                                                </div>
                                                                <?php if(!auth('customer')->check()): ?>
                                                                    <div class="col-sm-6">
                                                                        <div class="form-group mb-3">
                                                                            <label
                                                                                for="billing_contact_email"><?php echo e(translate('email')); ?></label>
                                                                            <input type="email"
                                                                                   name="billing_contact_email"
                                                                                   id="billing-contact-email"
                                                                                   class="form-control"
                                                                                   placeholder="<?php echo e(translate('ex')); ?>: <?php echo e(translate('email@domain.com')); ?>"
                                                                                   required>
                                                                        </div>
                                                                    </div>
                                                                <?php endif; ?>
                                                                <div class="col-sm-6">
                                                                    <div class="form-group mb-3">
                                                                        <label for="billing_address_type"
                                                                               class="text-capitalize"><?php echo e(translate('address_type')); ?></label>
                                                                        <select name="billing_address_type"
                                                                                id="billing-address-type"
                                                                                class="form-select">
                                                                            <option
                                                                                value="permanent"><?php echo e(translate('permanent')); ?></option>
                                                                            <option
                                                                                value="home"><?php echo e(translate('home')); ?></option>
                                                                            <option
                                                                                value="others"><?php echo e(translate('others')); ?></option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-6">
                                                                    <div class="form-group mb-3">
                                                                        <label
                                                                            for="billing-country"><?php echo e(translate('country')); ?></label>
                                                                        <select name="billing_country"
                                                                                id="billing-country"
                                                                                class="form-control select_picker select2">
                                                                            <?php $__empty_1 = true; $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                                <option
                                                                                    value="<?php echo e($country['name']); ?>"><?php echo e($country['name']); ?></option>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                                <option
                                                                                    value=""><?php echo e(translate('no_country_to_deliver')); ?></option>
                                                                            <?php endif; ?>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-6">
                                                                    <div class="form-group mb-3">
                                                                        <label
                                                                            for="billing-city"><?php echo e(translate('city')); ?></label>
                                                                        <input type="text" name="billing_city"
                                                                               id="billing-city"
                                                                               placeholder="<?php echo e(translate('ex')); ?>: <?php echo e(translate('Dhaka')); ?>"
                                                                               class="form-control" <?php echo e($billing_addresses->count()==0?'required':''); ?>>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-6">
                                                                    <div class="form-group mb-3">
                                                                        <label
                                                                            for="billing-zip"><?php echo e(translate('Zip_Code')); ?></label>
                                                                        <?php if($zip_restrict_status == 1): ?>
                                                                            <select name="billing_zip" id="billing-zip"
                                                                                    class="form-control select2 select_picker"
                                                                                    data-live-search="true" required>
                                                                                <?php $__empty_1 = true; $__currentLoopData = $zip_codes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                                    <option
                                                                                        value="<?php echo e($code->zipcode); ?>"><?php echo e($code->zipcode); ?></option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                                    <option
                                                                                        value=""><?php echo e(translate('no_zip_to_deliver')); ?></option>
                                                                                <?php endif; ?>
                                                                            </select>
                                                                        <?php else: ?>
                                                                            <input type="text" class="form-control"
                                                                                   id="billing-zip" name="billing_zip"
                                                                                   placeholder="<?php echo e(translate('ex')); ?>: <?php echo e(translate('1216')); ?>" <?php echo e($billing_addresses->count()==0?'required':''); ?>>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-12">
                                                                    <div class="form-group mb-3">
                                                                        <label
                                                                            for="billing-address"><?php echo e(translate('address')); ?></label>
                                                                        <div
                                                                            class="form-control focus-border rounded d-flex align-items-center">
                                                                            <input type="text" name="billing_address"
                                                                                   id="billing-address"
                                                                                   class="flex-grow-1 text-dark bg-transparent border-0 focus-input"
                                                                                   placeholder="<?php echo e(translate('your_address')); ?>" <?php echo e($shipping_addresses->count()==0?'required':''); ?>>

                                                                            <div class="border-start ps-3 pe-1"
                                                                                 data-bs-toggle="modal"
                                                                                 data-bs-target="#billingMapModal">
                                                                                <i class="bi bi-compass-fill"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <input type="hidden" name="billing_method_id"
                                                                       id="billing-method-id" value="0">
                                                                <?php if(auth('customer')->check()): ?>
                                                                    <div class="col-sm-12">
                                                                        <label
                                                                            class="custom-checkbox save-billing-address"
                                                                            id="save-billing-address-label">
                                                                            <input type="checkbox"
                                                                                   name="save_address_billing"
                                                                                   id="save_address_billing">
                                                                            <?php echo e(translate('save_this_address')); ?>

                                                                        </label>
                                                                    </div>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php echo $__env->make('theme-views.partials._order-summery', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </main>

    <span id="shipping-address-location"
          data-latitude="<?php echo e($default_location ? $default_location['lat'] : ''); ?>"
          data-longitude="<?php echo e($default_location ? $default_location['lng'] : ''); ?>">
</span>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(theme_asset('assets/js/shipping-page.js')); ?>"></script>
    <script
        src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(getWebConfig(name: 'map_api_key')); ?>&callback=mapsLoading&libraries=places&v=3.49"
        defer></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('theme-views.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/blunxtld/public_html/resources/themes/theme_aster/theme-views/checkout/shipping.blade.php ENDPATH**/ ?>