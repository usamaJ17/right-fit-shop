<h6 class="mb-3"><?php echo e(translate('Ratings')); ?></h6>
<ul class="common-nav nav flex-column">
    <li>
        <div class="flex-between-gap-3 align-items-center">
            <label class="custom-checkbox filter-by-rating" data-rating="5">
                <span class="star-rating text-gold">
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-fill"></i>
                </span>
            </label>
            <span class="badge bg-badge rounded-pill text-dark">
                <?php echo e($ratings['rating_5']); ?>

            </span>
        </div>
    </li>
    <li>
        <div class="flex-between-gap-3 align-items-center">
            <label class="custom-checkbox filter-by-rating" data-rating="4">
                <span class="star-rating text-gold">
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star"></i>
                </span>
            </label>
            <span class="badge bg-badge rounded-pill text-dark">
                <?php echo e($ratings['rating_4']); ?>

            </span>
        </div>
    </li>
    <li>
        <div class="flex-between-gap-3 align-items-center">
            <label class="custom-checkbox filter-by-rating" data-rating="3">
                <span class="star-rating text-gold">
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star"></i>
                    <i class="bi bi-star"></i>
                </span>
            </label>
            <span class="badge bg-badge rounded-pill text-dark">
                <?php echo e($ratings['rating_3']); ?>

            </span>
        </div>
    </li>
    <li>
        <div class="flex-between-gap-3 align-items-center">
            <label class="custom-checkbox filter-by-rating" data-rating="2">
                <span class="star-rating text-gold">
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star"></i>
                    <i class="bi bi-star"></i>
                    <i class="bi bi-star"></i>
                </span>
            </label>
            <span class="badge bg-badge rounded-pill text-dark">
                <?php echo e($ratings['rating_2']); ?>

            </span>
        </div>
    </li>
    <li>
        <div class="flex-between-gap-3 align-items-center">
            <label class="custom-checkbox filter-by-rating" data-rating="1">
                <span class="star-rating text-gold">
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star"></i>
                    <i class="bi bi-star"></i>
                    <i class="bi bi-star"></i>
                    <i class="bi bi-star"></i>
                </span>
            </label>
            <span class="badge bg-badge rounded-pill text-dark">
                <?php echo e($ratings['rating_1']); ?>

            </span>
        </div>
    </li>
</ul>
<?php /**PATH /home/blunxtld/public_html/resources/themes/theme_aster/theme-views/partials/_products_review_partials.blade.php ENDPATH**/ ?>