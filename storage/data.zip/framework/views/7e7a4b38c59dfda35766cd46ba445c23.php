<div class="modal-header border-0 pb-0 d-flex justify-content-end">
    <button type="button" class="btn-close border-0 reload-by-onclick" data-dismiss="modal" aria-label="Close">
        <i class="tio-clear"></i></button>
</div>
<div class="modal-body px-4 px-sm-5 text-center">
    <div class="mb-3 text-center">
        <img width="75" src="<?php echo e(asset('public/assets/back-end/img/shift.png')); ?>" alt="">
    </div>
    <h3>
        <?php echo e(translate('you_have_switched_theme_successfully')); ?>

        <br>
        <?php echo e(translate('from').' '.ucwords(str_replace('_',' ', $currentTheme)).' '.translate('to').' '.ucwords(str_replace('_',' ', $themeInfo['name']))); ?>

    </h3>
    <p>
        <?php echo e(translate('please_be_reminded_that_you_have_to_setup_data_for_these_section_for').' '. ucwords(str_replace('_',' ', $themeInfo['name'])).' '. translate('other_wise_these_section_data_would_not_function_properly_in_website_and_user_apps')); ?>

    </p>
    <div class="d-flex justify-content-center gap-3 my-5 flex-wrap">
        <?php
        $mergedArray = array_merge($currentThemeRoutes['route_list'], $themeRoutes['route_list']);
        $new_current_theme_routes = [];
        foreach ($currentThemeRoutes['route_list'] as $data) {
            if (!in_array($data['url'], array_column($themeRoutes['route_list'], 'url'))) {
                $new_current_theme_routes[] = $data;
            }
        }
        ?>
        <?php $__currentLoopData = $new_current_theme_routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(in_array($data['url'], array_column($mergedArray, 'url'))): ?>
                <a class="card p-3 w-fit-content cursor-pointer text-dark text-nowrap d-flex flex-row gap-2 align-items-center"
                   href="javascript:">
                    <?php echo e(translate($data['name'])); ?> <span class="badge badge-danger rounded-circle"><?php echo e('x'); ?></span>
                </a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $themeRoutes['route_list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(in_array($data['url'], array_column($mergedArray, 'url'))): ?>
                <a class="card p-3 w-fit-content cursor-pointer text-dark text-nowrap d-flex flex-row gap-2 align-items-center"
                   href="<?php echo e($data['url']); ?>" target="_blank">
                    <?php echo e(translate($data['name'])); ?> <span class="badge badge-success rounded-circle"><?php echo e('+'); ?></span>
                </a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <p class="mb-5 px-5"><span class="text-danger"><?php echo e(translate('note').':'); ?> </span>
        <?php echo e(translate('please_do_not_forget_to_notify_your_vendors_about_these_changes').'.'.translate('so_that_they_can_also_update_their_store_banners_according_to_the_new_theme_ratio')); ?>

    </p>
    <div class="d-flex flex-column gap-2 justify-content-center align-items-center notify-all-the-sellers-area" >
        <button type="button" class="fs-16 btn btn--primary px-sm-5 w-fit-content text-capitalize notify-all-the-sellers" >
            <?php echo e(translate('notify_all_the_vendors')); ?>

        </button>
        <button type="button" class="fs-16 btn btn-secondary px-sm-5 w-fit-content reload-by-onclick" data-dismiss="modal">
            <?php echo e(translate('skip')); ?>

        </button>
    </div>
</div>

<script>
    notifyAllTheSellers();
    locationReload();
</script>
<?php /**PATH /home/blunxtld/public_html/resources/views/admin-views/business-settings/partials/theme-information-modal-data.blade.php ENDPATH**/ ?>