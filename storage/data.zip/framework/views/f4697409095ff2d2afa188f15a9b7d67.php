<div class="modal fade" id="quickViewModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content" id="quickViewModal_content">
        </div>
    </div>
</div>
<?php /**PATH /home/blunxtld/public_html/resources/themes/theme_aster/theme-views/layouts/partials/modal/_quick-view.blade.php ENDPATH**/ ?>