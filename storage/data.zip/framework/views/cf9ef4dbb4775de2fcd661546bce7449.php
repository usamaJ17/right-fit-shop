<?php
    use App\Utils\Helpers;
?>

<?php $__env->startSection('title', translate('my_Profile').' | '.$web_config['name']->value.' '.translate('ecommerce')); ?>
<?php $__env->startSection('content'); ?>
    <main class="main-content d-flex flex-column gap-3 py-3 mb-4">
        <div class="container">
            <div class="row g-3">
                <?php echo $__env->make('theme-views.partials._profile-aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-lg-9">
                    <div class="card mb-3">
                        <div class="card-body">
                            <div class="d-flex gap-3 flex-wrap flex-grow-1">
                                <div class="card border flex-grow-1">
                                    <div class="card-body grid-center">
                                        <div class="text-center">
                                            <h3 class="mb-2"><?php echo e($total_order); ?></h3>
                                            <div class="d-flex align-items-center gap-2">
                                                <img width="16"
                                                     src="<?php echo e(theme_asset('assets/img/icons/profile-icon2.png')); ?>"
                                                     class="dark-support" alt="">
                                                <span><?php echo e(translate('Orders')); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card border flex-grow-1">
                                    <div class="card-body grid-center">
                                        <div class="text-center">
                                            <h3 class="mb-2"><?php echo e($wishlists); ?></h3>
                                            <div class="d-flex align-items-center gap-2">
                                                <img width="16"
                                                     src="<?php echo e(theme_asset('assets/img/icons/profile-icon3.png')); ?>"
                                                     class="dark-support" alt="">
                                                <span><?php echo e(translate('wishlist')); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card border flex-grow-1">
                                    <div class="card-body grid-center">
                                        <div class="text-center">
                                            <h3 class="mb-2"><?php echo e(Helpers::currency_converter($total_wallet_balance)); ?></h3>
                                            <div class="d-flex align-items-center gap-2">
                                                <img width="16"
                                                     src="<?php echo e(theme_asset('assets/img/icons/profile-icon5.png')); ?>"
                                                     class="dark-support" alt="">
                                                <span><?php echo e(translate('wallet')); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card border flex-grow-1">
                                    <div class="card-body grid-center">
                                        <div class="text-center">
                                            <h3 class="mb-2"><?php echo e($total_loyalty_point); ?></h3>
                                            <div class="d-flex align-items-center gap-2">
                                                <img width="16"
                                                     src="<?php echo e(theme_asset('assets/img/icons/profile-icon6.png')); ?>"
                                                     class="dark-support" alt="">
                                                <span class="text-capitalize"><?php echo e(translate('loyalty_point')); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="mt-30 bg-light rounded p-3">
                                <div class="d-flex align-items-center flex-wrap justify-content-between gap-3">
                                    <h5><?php echo e(translate('Personal_Details')); ?></h5>
                                    <a href="<?php echo e(route('user-account')); ?>"
                                       class="btn btn-outline-secondary rounded-pill px-3 px-sm-4"><span
                                            class="d-none d-sm-inline-block text-capitalize"><?php echo e(translate('edit_profile')); ?></span> <i
                                            class="bi bi-pencil-square"></i></a>
                                </div>

                                <div class="mt-4">
                                    <div class="row text-dark">
                                        <div class="col-md-6 col-xl-6 col-lg-6">
                                            <dl class="mb-0 flexible-grid width--7rem">
                                                <dt class="pe-1 text-capitalize"><?php echo e(translate('first_name')); ?></dt>
                                                <dd><?php echo e($customer_detail['f_name']); ?></dd>

                                                <dt class="pe-1 text-capitalize"><?php echo e(translate('last_name')); ?></dt>
                                                <dd><?php echo e($customer_detail['l_name']); ?></dd>
                                            </dl>
                                        </div>
                                        <div class="col-md-6 col-xl-6 col-lg-6">
                                            <dl class="mb-0 flexible-grid width--7rem">
                                                <dt class="pe-1"><?php echo e(translate('phone')); ?></dt>
                                                <dd><a href="tel:<?php echo e($customer_detail['phone']); ?>"
                                                       class="text-dark"><?php echo e($customer_detail['phone']); ?></a></dd>

                                                <dt class="pe-1"><?php echo e(translate('email')); ?></dt>
                                                <dd><a href="mailto:<?php echo e($customer_detail['email']); ?>"
                                                       class="text-dark"><?php echo e($customer_detail['email']); ?></a></dd>
                                            </dl>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
                                <h5 class="text-capitalize"><?php echo e(translate('my_addresses')); ?></h5>
                                <a href="<?php echo e(route('account-address-add')); ?>"
                                   class="btn btn-outline-secondary rounded-pill px-3 px-sm-4">
                                    <span class="d-none d-sm-inline-block text-capitalize"><?php echo e(translate('add_address')); ?></span>
                                        <i class="bi bi-geo-alt-fill"></i>
                                </a>
                            </div>
                            <div class="mt-3">
                                <div class="row gy-3 text-dark">
                                    <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-6">
                                            <div class="card border-0">
                                                <div
                                                    class="card-header gap-2 align-items-center d-flex justify-content-between">
                                                    <h6><?php echo e(translate($address['address_type'])); ?>

                                                        (<?php echo e($address['is_billing'] === 1 ? translate('billing_address'):translate('shipping_address')); ?>)</h6>
                                                    <div class="d-flex align-items-center gap-3">
                                                        <a href="<?php echo e(route('address-edit',$address->id)); ?>" class="p-0 bg-transparent border-0">
                                                            <img src="<?php echo e(theme_asset('assets/img/svg/location-edit.svg')); ?>"
                                                                alt="" class="svg">
                                                        </a>

                                                        <a href="javascript:"
                                                           data-action="<?php echo e(route('address-delete',['id'=>$address->id])); ?>"
                                                           data-message="<?php echo e(translate('want_to_delete_this_address').'?'); ?>"
                                                           class="p-0 bg-transparent border-0 delete-action">
                                                            <img src="<?php echo e(theme_asset('assets/img/svg/delete.svg')); ?>"
                                                                 alt="" class="svg">
                                                        </a>
                                                    </div>
                                                </div>
                                                <div class="card-body">
                                                    <address>
                                                        <dl class="mb-0 flexible-grid width--5rem">
                                                            <dt><?php echo e(translate('name')); ?></dt>
                                                            <dd><?php echo e($address['contact_person_name']); ?></dd>

                                                            <dt><?php echo e(translate('phone')); ?></dt>
                                                            <dd><a href="javascript:" class="text-dark"><?php echo e($address['phone']); ?></a>
                                                            </dd>
                                                            <dt><?php echo e(translate('address')); ?></dt>
                                                            <dd><?php echo e($address['address']); ?></dd>
                                                        </dl>
                                                    </address>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme-views.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/blunxtld/public_html/resources/themes/theme_aster/theme-views/users-profile/profile/user-profile.blade.php ENDPATH**/ ?>