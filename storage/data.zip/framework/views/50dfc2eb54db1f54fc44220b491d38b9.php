<?php $__env->startSection('title',translate('customer_wallet')); ?>
<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <div class="mb-3 d-flex justify-content-between flex-wrap gap-3">
            <h2 class="h1 mb-0 text-capitalize d-flex align-items-center gap-2">
                <img width="20" src="<?php echo e(asset('/public/assets/back-end/img/admin-wallet.png')); ?>" alt="">
                <?php echo e(translate('wallet')); ?>

            </h2>
            <?php if($customerStatus == 1): ?>
                <button type="button" class="btn btn--primary text-capitalize" data-toggle="modal" data-target="#add-fund-modal">
                    <?php echo e(translate('add_fund')); ?>

                </button>
            <?php endif; ?>
        </div>
        <div class="modal fade" id="add-fund-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header d-flex justify-content-between">
                        <h5 class="modal-title text-capitalize" id="exampleModalLongTitle"><?php echo e(translate('add_fund')); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('admin.customer.wallet.add-fund')); ?>" method="post" enctype="multipart/form-data" id="add-fund">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-sm-6 col-12">
                                    <div class="form-group">
                                        <label class="input-label d-flex" for="customer"><?php echo e(translate('customer')); ?></label>
                                        <select id='form-customer' name="customer_id" data-placeholder="<?php echo e(translate('select_customer')); ?>" class="get-customer-list-by-ajax-request" required>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-12">
                                    <div class="form-group">
                                        <label class="input-label d-flex" for="amount"><?php echo e(translate('amount')); ?></label>
                                        <input type="number" class="form-control" name="amount" id="amount" step=".01" placeholder="<?php echo e(translate('ex').':'.'500'); ?>" required>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                        <label class="input-label d-flex align-items-center gap-1" for="reference"><?php echo e(translate('reference')); ?> <small>(<?php echo e(translate('optional')); ?>)</small></label>
                                        <input type="text" class="form-control" name="reference" placeholder="<?php echo e(translate('ex').':'.'abc990'); ?>" id="reference">
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-end gap-3">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(translate('close')); ?></button>
                                <button type="submit" id="submit" class="btn btn--primary px-4"><?php echo e(translate('submit')); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="card  mt-3">
            <div class="card-header text-capitalize">
                <h4 class="mb-0"><?php echo e(translate('filter_options')); ?></h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-12 pt-3">
                        <form action="<?php echo e(route('admin.customer.wallet.report')); ?>" method="get">
                            <div class="row">
                                <div class="col-sm-6 col-12">
                                    <div class="mb-3">
                                        <input type="date" name="from" id="start-date-time" value="<?php echo e(request()->get('from')); ?>" class="form-control" title="<?php echo e(ucfirst(translate('from_date'))); ?>">
                                    </div>
                                </div>
                                <div class="col-sm-6 col-12">
                                    <div class="mb-3">
                                        <input type="date" name="to" id="end-date-time" value="<?php echo e(request()->get('to')); ?>" class="form-control" title="<?php echo e(ucfirst(translate('to_date'))); ?>">
                                    </div>
                                </div>
                                <div class="col-sm-6 col-12">
                                    <div class="mb-3">
                                        <?php
                                        $transaction_status=request()->get('transaction_type');
                                        ?>
                                        <select name="transaction_type" class="form-control" title="<?php echo e(translate('select_transaction_type')); ?>">
                                            <option value=""><?php echo e(translate('all')); ?></option>
                                            <option value="add_fund_by_admin" <?php echo e(isset($transaction_status) && $transaction_status=='add_fund_by_admin'?'selected':''); ?> ><?php echo e(translate('add_fund_by_admin')); ?></option>
                                            <option value="add_fund" <?php echo e(isset($transaction_status) && $transaction_status=='add_fund'?'selected':''); ?> ><?php echo e(translate('add_fund')); ?></option>
                                            <option value="order_refund" <?php echo e(isset($transaction_status) && $transaction_status=='order_refund'?'selected':''); ?>><?php echo e(translate('refund_order')); ?></option>
                                            <option value="loyalty_point" <?php echo e(isset($transaction_status) && $transaction_status=='loyalty_point'?'selected':''); ?>><?php echo e(translate('customer_loyalty_point')); ?></option>
                                            <option value="order_place" <?php echo e(isset($transaction_status) && $transaction_status=='order_place'?'selected':''); ?>><?php echo e(translate('order_place')); ?></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-12">
                                    <div class="mb-3">
                                        <input type="hidden" id='customer-id'  name="customer_id" value="<?php echo e(request('customer_id') ?? 'all'); ?>">
                                        <select data-placeholder="
                                                    <?php if($customer == 'all'): ?>
                                                        <?php echo e(translate('all_customer')); ?>

                                                    <?php else: ?>
                                                        <?php echo e($customer['name'] ?? $customer['f_name'].' '.$customer['l_name'].' '.'('.$customer['phone'].')'); ?>

                                                    <?php endif; ?>"
                                                 class="get-customer-list-by-ajax-request form-control form-ellipsis set-customer-value">
                                            <option value="all"><?php echo e(translate('all_customer')); ?></option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-end">
                                <button type="submit" class="btn btn--primary px-4"><i class="tio-filter-list mr-1"></i><?php echo e(translate('filter')); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>
        <div class="card mt-3">
            <div class="card-header text-capitalize">
                <h4 class="mb-0"><?php echo e(translate('summary')); ?></h4>
            </div>
            <div class="card-body">
                <div class="d-flex flex-wrap gap-3">
                    <?php
                        $credit = $data[0]->total_credit;
                        $debit = $data[0]->total_debit;
                        $balance = $credit - $debit;
                    ?>
                    <div class="order-stats flex-grow-1">
                        <div class="order-stats__content">
                            <i class="tio-atm"></i>
                            <h6 class="order-stats__subtitle"><?php echo e(translate('debit')); ?></h6>
                        </div>
                        <span class="order-stats__title fz-14 text--primary">
                            <?php echo e(setCurrencySymbol(amount: usdToDefaultCurrency(amount: $debit??0))); ?>

                        </span>
                    </div>
                    <div class="order-stats flex-grow-1">
                        <div class="order-stats__content">
                            <i class="tio-money"></i>
                            <h6 class="order-stats__subtitle"><?php echo e(translate('credit')); ?></h6>
                        </div>
                        <span class="order-stats__title fz-14 text-warning">
                        <?php echo e(setCurrencySymbol(amount: usdToDefaultCurrency(amount:$credit??0))); ?>

                        </span>
                    </div>
                    <div class="order-stats flex-grow-1">
                        <div class="order-stats__content">
                            <i class="tio-wallet"></i>
                            <h6 class="order-stats__subtitle"><?php echo e(translate('balance')); ?></h6>
                        </div>
                        <span class="order-stats__title fz-14 text-success">
                            <?php echo e(setCurrencySymbol(amount: usdToDefaultCurrency(amount:$balance??0))); ?>

                        </span>
                    </div>
                </div>
            </div>

        </div>
        <div class="card mt-3">
            <div class="card-header text-capitalize gap-2">
                <h4 class="mb-0 text-nowrap ">
                    <?php echo e(translate('transactions')); ?>

                    <span class="badge badge-soft-dark radius-50 fz-12 ml-1"><?php echo e($transactions->total()); ?></span>
                </h4>
                <div class="d-flex justify-content-end">
                    <div class="dropdown text-nowrap">
                        <button type="button" class="btn btn-outline--primary" data-toggle="dropdown">
                            <i class="tio-download-to"></i>
                            <?php echo e(translate('export')); ?>

                            <i class="tio-chevron-down"></i>
                        </button>

                        <ul class="dropdown-menu dropdown-menu-right">
                            <li>
                                <a type="submit" class="dropdown-item d-flex align-items-center gap-2 " href="<?php echo e(route('admin.customer.wallet.export',['transaction_type'=>$transaction_status,'customer_id'=>request('customer_id'),'to'=>request('to'),'from'=>request('from')])); ?>">
                                    <img width="14" src="<?php echo e(asset('/public/assets/back-end/img/excel.png')); ?>" alt="">
                                    <?php echo e(translate('excel')); ?>

                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="table-responsive">
                <table id="datatable"
                    class="table table-hover table-borderless table-thead-bordered table-nowrap table-align-middle card-table <?php echo e(Session::get('direction') === "rtl" ? 'text-right' : 'text-left'); ?>">
                    <thead class="thead-light thead-50 text-capitalize">
                        <tr>
                            <th><?php echo e(translate('SL')); ?></th>
                            <th><?php echo e(translate('transaction_ID')); ?></th>
                            <th><?php echo e(translate('Customer')); ?></th>
                            <th><?php echo e(translate('credit')); ?></th>
                            <th><?php echo e(translate('debit')); ?></th>
                            <th><?php echo e(translate('balance')); ?></th>
                            <th><?php echo e(translate('transaction_type')); ?></th>
                            <th><?php echo e(translate('reference')); ?></th>
                            <th class="text-center"><?php echo e(translate('created_at')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($transactions->firstItem()+($key)); ?></td>
                            <td><?php echo e($transaction['transaction_id']); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.customer.view',['user_id'=>$transaction['user_id']])); ?>" class="title-color hover-c1"><?php echo e(Str::limit($transaction['user'] ? $transaction?->user->f_name.' '.$transaction?->user->l_name : translate('not_found'),20)); ?></a>
                            </td>
                            <td>
                                <?php echo e(setCurrencySymbol(amount: usdToDefaultCurrency(amount:$transaction['credit']))); ?>

                                <?php if($transaction['transaction_type'] == 'add_fund' && $transaction['admin_bonus'] > 0): ?>
                                    <span class="text-sm badge badge-soft-success">
                                        + <?php echo e(setCurrencySymbol(amount: usdToDefaultCurrency(amount:$transaction['admin_bonus']))); ?> <?php echo e(translate('admin_bonus')); ?>

                                    </span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e(setCurrencySymbol(amount: usdToDefaultCurrency(amount:$transaction['debit']))); ?></td>

                            <td>
                                <?php echo e(setCurrencySymbol(amount: usdToDefaultCurrency(amount:$transaction['balance']))); ?>

                            </td>

                            <td>
                                <span class="badge badge-soft-<?php echo e($transaction['transaction_type']=='order_refund' ?'danger'
                                    :($transaction['transaction_type']=='loyalty_point'?'warning'
                                        :($transaction['transaction_type']=='order_place'
                                            ?'info'
                                            :'success'))); ?>">
                                    <?php echo e(translate($transaction['transaction_type'])); ?>

                                </span>
                            </td>
                            <td><?php echo e(translate(str_replace('_',' ',$transaction['reference']))); ?></td>
                            <td class="text-center"><?php echo e(date('Y/m/d '.config('timeformat'), strtotime($transaction['created_at']))); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="table-responsive mt-4">
                <div class="px-4 d-flex justify-content-lg-end">
                    <?php echo $transactions->links(); ?>

                </div>
            </div>
            <?php if(count($transactions)==0): ?>
                <div class="text-center p-4">
                    <img class="mb-3 w-160" src="<?php echo e(asset('public/assets/back-end/svg/illustrations/sorry.svg')); ?>" alt="<?php echo e(translate('image_description')); ?>">
                    <p class="mb-0"><?php echo e(translate('no_data_to_show')); ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        'use strict' ;
        $('#add-fund').on('submit', function (e) {
            e.preventDefault();
            let formData = new FormData(this);
            Swal.fire({
                title: "<?php echo e(translate('are_you_sure').'?'); ?> ",
                text: '<?php echo e(translate("you_want_to_add_fund")); ?> '+$('#amount').val()+' <?php echo e(getCurrencyCode(type: 'default').' '.translate("to")); ?> '+$('#form-customer option:selected').text()+'<?php echo e(translate("to_wallet")); ?>',
                type: 'info',
                showCancelButton: true,
                cancelButtonColor: 'default',
                confirmButtonColor: 'primary',
                cancelButtonText: '<?php echo e(translate("no")); ?>',
                confirmButtonText: '<?php echo e(translate("add")); ?>',
                reverseButtons: true
            }).then((result) => {
                if (result.value) {
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.post({
                        url: '<?php echo e(route('admin.customer.wallet.add-fund')); ?>',
                        data: formData,
                        cache: false,
                        contentType: false,
                        processData: false,
                        success: function (data) {
                            if (data.errors) {
                                for (let i = 0; i < data.errors.length; i++) {
                                    toastr.error(data.errors[i].message, {
                                        CloseButton: true,
                                        ProgressBar: true
                                    });
                                }
                            } else {
                                toastr.success('<?php echo e(translate("fund_added_successfully")); ?>', {
                                    CloseButton: true,
                                    ProgressBar: true
                                });
                                location.reload();
                            }
                        }
                    });
                }
            })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.back-end.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/blunxtld/public_html/resources/views/admin-views/customer/wallet/report.blade.php ENDPATH**/ ?>