<div class="pos-product-item card action-select-product" data-id="<?php echo e($product['id']); ?>">
    <div class="pos-product-item_thumb">
        <img class="img-fit" src="<?php echo e(getValidImage(path: 'storage/app/public/product/thumbnail/'.$product['thumbnail'], type: 'backend-product')); ?>"
             alt="<?php echo e($product['name']); ?>">
    </div>

    <div class="pos-product-item_content clickable">
        <div class="pos-product-item_title">
            <?php echo e($product['name']); ?>

        </div>
        <div class="pos-product-item_price">
            <?php echo e(setCurrencySymbol(amount: usdToDefaultCurrency(amount: $product['unit_price'] - getProductDiscount(product: $product, price: $product['unit_price'])), currencyCode: getCurrencyCode())); ?>

        </div>
        <div class="pos-product-item_hover-content">
            <div class="d-flex flex-wrap gap-2">
                <span class="fz-22">
                    <?php echo e($product['product_type'] == 'physical' ? $product['current_stock'] : translate('in_Stock')); ?>

                </span>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/blunxtld/public_html/resources/views/admin-views/pos/partials/_single-product.blade.php ENDPATH**/ ?>