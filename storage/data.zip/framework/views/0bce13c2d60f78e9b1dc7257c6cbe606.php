<?php use App\Utils\Helpers;use App\Utils\ProductManager;use Illuminate\Support\Str; ?>
<?php ($overallRating = $product->reviews ? getOverallRating($product->reviews) : 0); ?>
<div class="product d-flex flex-column gap-10 get-view-by-onclick" data-link="<?php echo e(route('product',$product->slug)); ?>">
    <div class="product__top border rounded">
        <?php if($product->discount > 0): ?>
            <span class="product__discount-badge">
                <span>
                    <?php if($product->discount_type == 'percent'): ?>
                        <?php echo e('-'.' '.round($product->discount, $web_config['decimal_point_settings']).'%'); ?>

                    <?php elseif($product->discount_type =='flat'): ?>
                        <?php echo e('-'.' '.Helpers::currency_converter($product->discount)); ?>

                    <?php endif; ?>
                </span>
            </span>
        <?php endif; ?>
        <?php ($wishlist = count($product->wishList)>0 ? 1 : 0); ?>
        <?php ($compare_list = count($product->compareList)>0 ? 1 : 0); ?>
        <div class="product__actions d-flex flex-column gap-2">
            <a href="javascript:"
               data-action="<?php echo e(route('store-wishlist')); ?>"
               data-product-id="<?php echo e($product['id']); ?>"
               id="wishlist-<?php echo e($product['id']); ?>"
               class="btn-wishlist stopPropagation add-to-wishlist wishlist-<?php echo e($product['id']); ?> <?php echo e(($wishlist == 1?'wishlist_icon_active':'')); ?>"
               title="<?php echo e(translate('add_to_wishlist')); ?>">
                <i class="bi bi-heart"></i>
            </a>
            <a href="javascript:"
               class="btn-compare stopPropagation add-to-compare compare_list-<?php echo e($product['id']); ?> <?php echo e(($compare_list == 1?'compare_list_icon_active':'')); ?>"
               title="<?php echo e(translate('add_to_compare')); ?>"
               data-action="<?php echo e(route('product-compare.index')); ?>"
               data-product-id="<?php echo e($product['id']); ?>"
               id="compare_list-<?php echo e($product['id']); ?>">
                <i class="bi bi-repeat"></i>
            </a>
            <a href="javascript:"
               data-action="<?php echo e(route('quick-view')); ?>"
               data-product-id="<?php echo e($product['id']); ?>"
               class="btn-quickview stopPropagation get-quick-view" title="<?php echo e(translate('quick_view')); ?>">
                <i class="bi bi-eye"></i>
            </a>
        </div>

        <div>
            <img src="<?php echo e(getValidImage(path: 'storage/app/public/product/thumbnail/'.$product['thumbnail'], type: 'product')); ?>"
                 loading="lazy" class="img-fit dark-support rounded" alt="">
        </div>
    </div>
    <div class="product__summary d-flex flex-column gap-1 cursor-pointer">
        <div class="d-flex gap-2 align-items-center">
            <div class="star-rating text-gold fs-12">
                <?php for($index = 1; $index <= 5; $index++): ?>
                    <?php if($index <= (int)$overallRating[0]): ?>
                        <i class="bi bi-star-fill"></i>
                    <?php elseif($overallRating[0] != 0 && $index <= (int)$overallRating[0] + 1.1 && $overallRating[0] > ((int)$overallRating[0])): ?>
                        <i class="bi bi-star-half"></i>
                    <?php else: ?>
                        <i class="bi bi-star"></i>
                    <?php endif; ?>
                <?php endfor; ?>
            </div>
            <span>( <?php echo e($product->reviews->count()); ?> )</span>
        </div>

        <div class="text-muted fs-12">
            <?php if($product->added_by=='seller'): ?>
                <?php echo e(isset($product->seller->shop->name) ? Str::limit($product->seller->shop->name, 20) : ''); ?>

            <?php elseif($product->added_by=='admin'): ?>
                <?php echo e($web_config['name']->value); ?>

            <?php endif; ?>
        </div>

        <h6 class="product__title text-truncate width--80">
            <?php echo e(Str::limit($product['name'], 18)); ?>

        </h6>

        <div class="product__price d-flex flex-wrap column-gap-2">
            <?php if($product->discount > 0): ?>
                <del class="product__old-price"><?php echo e(Helpers::currency_converter($product->unit_price)); ?></del>
            <?php endif; ?>
            <ins class="product__new-price">
                <?php echo e(Helpers::currency_converter($product->unit_price-Helpers::get_product_discount($product,$product->unit_price))); ?>

            </ins>
        </div>
    </div>
</div>
<?php /**PATH /home/blunxtld/public_html/resources/themes/theme_aster/theme-views/partials/_product-medium-card.blade.php ENDPATH**/ ?>